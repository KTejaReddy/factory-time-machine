import { useState } from "react";
import { UtilisationChart } from "../components/charts";
import { Card, ErrorBox, Spinner, Stat, UtilBar } from "../components/ui";
import { Term } from "../components/Glossary";
import { api, type StationRow } from "../lib/api";
import { int, num, useApi } from "../lib/hooks";

export default function Production() {
  const snapshot = useApi(() => api.productionSnapshot(), []);
  const anomalies = useApi(() => api.anomalies(undefined, 5), []);

  const snap = snapshot.data;
  const stations: StationRow[] = snap?.stations ?? [];
  const measured = stations.filter((s) => s.utilization !== null && s.utilization !== undefined);
  const topAnomaly = anomalies.data?.top?.[0];

  return (
    <div className="space-y-6 max-w-5xl">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-[24px] font-bold tracking-tight">Factory Analysis</h1>
          <p className="mt-2 text-[14px] text-[var(--color-ink-dim)]">
            Understand the current health and performance of the factory.
          </p>
        </div>
        {/* Dynamic active dataset is passed automatically via api.ts */}
      </header>

      {snapshot.loading ? (
        <Spinner label="Loading factory data..." />
      ) : snapshot.error ? (
        <ErrorBox message={snapshot.error} onRetry={snapshot.reload} />
      ) : (
        <div className="space-y-6">
          <Card title="📊 Production">
            <div className="grid gap-4 sm:grid-cols-2">
              <Stat 
                label="Throughput" 
                value={snap?.throughput_total ? int(snap.throughput_total) : "—"} 
                unit="parts / run" 
                tone="accent" 
              />
              <Stat 
                label="Parts waiting (WIP)" 
                value={num(snap?.wip_total ?? 0, 1)} 
                unit="parts" 
              />
            </div>
            
            <div className="mt-6 border-t border-[var(--color-edge)] pt-4">
              <h3 className="text-[14px] font-semibold mb-4">How busy is each station?</h3>
              <div className="h-[200px]">
                <UtilisationChart
                  data={measured.map((s) => ({ label: s.label, utilization: s.utilization ?? null, rank: s.rank }))}
                />
              </div>
            </div>
          </Card>

          <Card title="⚠️ Unusual Factory Activity">
            {anomalies.loading ? (
              <Spinner />
            ) : !topAnomaly ? (
              <div className="text-[14px] text-[var(--color-ink-dim)]">Everything looks normal.</div>
            ) : (
              <div className="space-y-4">
                <p className="text-[14px] text-[var(--color-bad)] font-medium">
                  This production run looks different from the normal pattern.
                </p>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Stat label="Most Unusual Run" value={`#${topAnomaly.run_index}`} tone="warn" />
                </div>
                <div>
                  <div className="text-[13px] font-semibold mb-2">Why?</div>
                  <ul className="list-disc list-inside text-[13px] text-[var(--color-ink-dim)] space-y-1">
                    {topAnomaly.drivers.slice(0, 3).map((d: any, idx: number) => (
                      <li key={idx}>{d.feature} is unusually {d.z > 0 ? "high" : "low"}</li>
                    ))}
                  </ul>
                </div>

                <details className="mt-4 border-t border-[var(--color-edge)] pt-4 text-[13px] text-[var(--color-ink-dim)] cursor-pointer">
                  <summary className="font-semibold text-[var(--color-ink)]">How this was calculated ▾</summary>
                  <div className="mt-2 space-y-2">
                    <p><strong>Algorithm:</strong> PCA + Mahalanobis Distance.</p>
                    <p><strong>Purpose:</strong> Find production runs that look very different from normal runs.</p>
                    <p><strong>Threshold:</strong> Top 0.5% (99.5th percentile) most distant runs are flagged.</p>
                  </div>
                </details>
              </div>
            )}
          </Card>

          <Card title="🚧 Bottleneck">
            <p className="text-[14px] mb-4 text-[var(--color-bad)] font-medium">
              This is the station currently showing the strongest signs of being a bottleneck.
            </p>
            <div className="overflow-x-auto">
              <table className="table w-full text-left">
                <thead>
                  <tr>
                    <th>Station</th>
                    <th><Term name="utilization">How busy?</Term></th>
                    <th>Why it is flagged</th>
                  </tr>
                </thead>
                <tbody>
                  {stations.slice(0, 5).map((station) => (
                    <tr key={station.station}>
                      <td className="font-medium">{station.label}</td>
                      <td className="w-1/3">
                        <UtilBar value={station.utilization} />
                      </td>
                      <td className="max-w-[300px]">
                        <ul className="space-y-1 text-[13px] text-[var(--color-ink-dim)]">
                          {(station.utilization ?? 0) > 0.8 && <li>· Very busy</li>}
                          {(station.wip_evidence ?? 0) > 5 && <li>· Queue is building</li>}
                          {(station.capacity ?? 0) < 3 && <li>· Limited capacity</li>}
                          {(!station.utilization || !station.wip_evidence) && <li>· Data missing</li>}
                        </ul>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>                <details className="mt-4 border-t border-[var(--color-edge)] pt-4 text-[13px] text-[var(--color-ink-dim)] cursor-pointer">
                  <summary className="font-semibold text-[var(--color-ink)]">How this was calculated ▾</summary>
                  <div className="mt-2 space-y-2">
                    <p><strong>Algorithm:</strong> Weighted composite score: <Term name="utilization">utilisation</Term> 0.80, WIP/<Term name="queue">queue</Term> rank 0.12, capacity constraint 0.08.</p>
                    <p><strong>Meaning:</strong> The busiest station dominates the ranking; the other two terms only break near-ties.</p>
                    <p><strong>Note:</strong> This is arithmetic on the exported data — a formula, not an AI judgement.</p>
                  </div>
                </details>
          </Card>
        </div>
      )}
    </div>
  );
}
