import { useEffect, useState } from "react";
import { Badge, Card, Empty, ErrorBox, FeedbackBar, Spinner, Stat } from "../components/ui";
import { api, type ExternalImageEntry, type InspectionPrediction } from "../lib/api";
import { pct, useApi } from "../lib/hooks";

const GRID = 8;

function AttentionOverlay({ prediction }: { prediction: InspectionPrediction }) {
  const cells = Array.from({ length: GRID * GRID }, (_, i) => {
    const gx = i % GRID;
    const gy = Math.floor(i / GRID);
    const match = prediction.attention.find((a) => Math.round(a.x * GRID) === gx && Math.round(a.y * GRID) === gy);
    return { gx, gy, weight: match?.weight ?? 0 };
  });
  return (
    <div className="pointer-events-none absolute inset-0">
      <div className="grid h-full w-full" style={{ gridTemplateColumns: `repeat(${GRID}, 1fr)`, gridTemplateRows: `repeat(${GRID}, 1fr)` }}>
        {cells.map((cell) => (
          <div
            key={`${cell.gx}-${cell.gy}`}
            style={{ background: cell.weight > 0 ? `rgba(251,113,133,${0.12 + cell.weight * 0.45})` : "transparent" }}
          />
        ))}
      </div>
    </div>
  );
}

function ResultPanel({
  prediction,
  imageUrl,
  external,
}: {
  prediction: InspectionPrediction;
  imageUrl: string;
  external?: boolean;
}) {
  const [showAttention, setShowAttention] = useState(true);
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4 text-[18px] font-bold">
        {prediction.uncertain ? (
          <span className="text-[var(--color-warn)]">⚠️ Not Sure</span>
        ) : prediction.defect ? (
          <span className="text-[var(--color-bad)]">❌ Defect</span>
        ) : (
          <span className="text-[var(--color-ok)]">✅ Normal</span>
        )}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Stat label="Prediction" value={prediction.label_display} />
        <Stat label="Confidence" value={pct(prediction.confidence * 100, 1)} tone={prediction.uncertain ? "warn" : "accent"} />        <Stat
          label="Flip check (TTA)"
          value={pct(prediction.tta_agreement * 100, 0)}
          hint="The image and its mirror must agree. Low agreement means the model is guessing."
        />
        <Stat
          label="Verdict"
          value={prediction.uncertain ? "Uncertain" : "Confident"}
          tone={prediction.uncertain ? "warn" : "ok"}
          hint={prediction.uncertain ? prediction.uncertainty_reason : undefined}
        />
      </div>

      {external && (
        <div className="rounded-lg border border-dashed border-[rgba(167,139,250,0.5)] bg-[rgba(167,139,250,0.07)] p-3 text-[12.5px] text-[#c4b5fd]">
          🧪 <strong>External Test Image — Not Used for Training.</strong> This image lives outside the training
          archive and is never fed back to the model. If it looks nothing like factory images, treat the prediction
          as a robustness probe, not a quality call.
        </div>
      )}

      {prediction.out_of_distribution && (
        <div className="rounded-lg border border-[rgba(251,191,36,0.45)] bg-[rgba(251,191,36,0.07)] p-3 text-[12.5px] leading-relaxed text-[#fde68a]">
          ⚠️ <strong>Outside the training distribution.</strong> This image looks nothing like what the model was
          trained on (distance {prediction.ood_distance?.toFixed(3)} vs threshold {prediction.ood_threshold}).
          The prediction above is the model's honest best guess — but the model can be <em>confidently wrong</em> on
          images like this, so do not act on it as a quality decision.
        </div>
      )}

      <div>
        <div className="mb-2 flex items-center justify-between">
          <span className="text-[14px] font-semibold">Where the model looked:</span>
          <label className="flex items-center gap-2 text-[12px] text-[var(--color-ink-dim)]">
            <input type="checkbox" checked={showAttention} onChange={(e) => setShowAttention(e.target.checked)} />
            Show highlight
          </label>
        </div>
        <div className="relative w-full max-w-[256px] overflow-hidden rounded-lg border border-[var(--color-edge)] bg-black">
          <img src={imageUrl} alt={prediction.specimen} className="block h-[256px] w-[256px]" />
          {showAttention && <AttentionOverlay prediction={prediction} />}
        </div>
        {showAttention && (
          <p className="mt-2 text-[12px] text-[var(--color-ink-dim)]">
            The highlighted area is where the AI focused when making its decision. The dataset contains no defect
            location labels, so this is model attention — not a measured defect position.
          </p>
        )}
      </div>

      <details className="mt-4 cursor-pointer border-t border-[var(--color-edge)] pt-4 text-[13px] text-[var(--color-ink-dim)]">
        <summary className="font-semibold text-[var(--color-ink)]">How this was calculated ▾</summary>
        <div className="mt-2 space-y-2">
          <p>
            <strong>AI Model:</strong> A small custom CNN (6 convolution layers) trained on 12,000 labelled factory
            images in 5 classes: crack, hole, normal, rust, scratch.
          </p>
          <p>
            <strong>Confidence:</strong> The model's probability for the winning class, averaged with the same image
            mirrored horizontally (test-time augmentation).
          </p>
          <p>
            <strong>Flip check (TTA):</strong> If the image and its mirror produce very different answers, the
            prediction is flagged uncertain.
          </p>
          <p>
            <strong>Outside-training check:</strong> The image is compared against the training images in the
            model's feature space. When it sits far from all of them, the result is flagged so a confidently-wrong
            answer is not mistaken for a real inspection.
          </p>
          <p>
            <strong>Highlight (Grad-CAM):</strong> Shows which image regions most influenced the winning class.
          </p>
        </div>
      </details>
    </div>
  );
}

export default function Inspection() {
  const samples = useApi(() => api.inspectSamples(8), []);
  const externalInfo = useApi(() => api.externalInfo(), []);
  const externalList = useApi(() => api.externalList(undefined, 40), []);

  const [tab, setTab] = useState<"training" | "external">("training");
  const [specimen, setSpecimen] = useState<string | null>(null);
  const [prediction, setPrediction] = useState<InspectionPrediction | null>(null);
  const [isExternal, setIsExternal] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const [uploading, setUploading] = useState(false);
  const [uploadNote, setUploadNote] = useState("");
  const [generating, setGenerating] = useState(false);
  const [genKind, setGenKind] = useState<"mixed" | "variation" | "nonfactory">("mixed");

  useEffect(() => {
    if (!specimen && samples.data?.samples) {
      const first = Object.values(samples.data.samples)[0]?.[0];
      if (first) setSpecimen(first);
    }
  }, [samples.data, specimen]);

  const runInspection = async (name: string) => {
    setSpecimen(name);
    setIsExternal(false);
    setLoading(true);
    setError(null);
    try {
      setPrediction(await api.predict(name));
    } catch (err) {
      setPrediction(null);
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  const runExternal = async (id: string) => {
    setIsExternal(true);
    setLoading(true);
    setError(null);
    try {
      setPrediction(await api.externalPredict(id));
    } catch (err) {
      setPrediction(null);
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  const upload = async (file: File | undefined | null) => {
    if (!file) return;
    // Refuse locally what the server would refuse anyway, so the user is not made
    // to wait out a doomed upload just to read a size error afterwards.
    const limit = externalInfo.data?.max_upload_bytes;
    if (limit && file.size > limit) {
      setError(
        `This image is ${(file.size / (1024 * 1024)).toFixed(1)} MB, above the ${Math.floor(limit / (1024 * 1024))} MB limit. ` +
          "Please pick a smaller file (or resize it first).",
      );
      return;
    }
    setUploading(true);
    setError(null);
    try {
      const entry = await api.externalUpload(file, uploadNote);
      setUploadNote("");
      await externalList.reload();
      await externalInfo.reload();
      await runExternal(entry.id);
      setTab("external");
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setUploading(false);
    }
  };

  const generate = async () => {
    setGenerating(true);
    setError(null);
    try {
      await api.externalGenerate(genKind, 6);
      await externalList.reload();
      await externalInfo.reload();
      setTab("external");
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setGenerating(false);
    }
  };

  const remove = async (id: string) => {
    try {
      await api.externalDelete(id);
      if (isExternal && prediction?.external?.id === id) {
        setPrediction(null);
      }
      await externalList.reload();
      await externalInfo.reload();
    } catch (err) {
      setError((err as Error).message);
    }
  };

  const entries = externalList.data ?? [];

  return (
    <div className="space-y-6 max-w-5xl">
      <header>
        <h1 className="text-[24px] font-bold tracking-tight">Inspect</h1>
        <p className="mt-2 text-[14px] text-[var(--color-ink-dim)]">
          Pick a product image and let the AI check it for defects — or test it with your own image.
        </p>
      </header>

      <div className="flex gap-2">
        <button className={`btn ${tab === "training" ? "btn-primary" : ""}`} onClick={() => setTab("training")}>
          📁 Factory images
        </button>
        <button className={`btn ${tab === "external" ? "btn-primary" : ""}`} onClick={() => setTab("external")}>
          🧪 Test with a new image
        </button>
      </div>

      {tab === "training" ? (
        <div className="grid gap-6 md:grid-cols-2">
          <Card title="1. Select Image">
            {samples.loading ? (
              <Spinner />
            ) : (
              <div className="flex flex-wrap gap-2">
                {Object.entries(samples.data?.samples ?? {}).map(([_, names]) =>
                  names.map((name) => (
                    <button
                      key={name}
                      onClick={() => runInspection(name)}
                      title={name}
                      className={`h-[64px] w-[64px] overflow-hidden rounded border-2 ${
                        specimen === name && !isExternal ? "border-[var(--color-accent)]" : "border-[var(--color-edge)]"
                      }`}
                    >
                      <img src={api.thumbnailUrl(name, 128)} alt={name} loading="lazy" className="h-full w-full object-cover" />
                    </button>
                  )),
                )}
              </div>
            )}
            <p className="mt-3 text-[11.5px] text-[var(--color-ink-faint)]">
              These images come from the training archive, so the model has seen similar ones. For a fair test, use
              your own image on the “Test with a new image” tab.
            </p>
          </Card>

          <Card title="2. AI Checks It">
            {loading && !isExternal ? (
              <Spinner label="AI is checking..." />
            ) : error && !isExternal ? (
              <ErrorBox message={error} onRetry={() => specimen && runInspection(specimen)} />
            ) : !prediction || isExternal ? (
              <Empty>Select an image to check.</Empty>
            ) : (
              <ResultPanel prediction={prediction} imageUrl={api.imageUrl(prediction.specimen)} />
            )}
          </Card>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="rounded-lg border border-dashed border-[rgba(167,139,250,0.5)] bg-[rgba(167,139,250,0.06)] p-3.5 text-[12.5px] leading-relaxed text-[#c4b5fd]">
            🧪 <strong>External Test Image — Not Used for Training.</strong> Everything on this tab is stored outside
            the training archive (in <span className="mono">data/external_test/</span>) and is never added to the
            model's training data. Use it to see how the AI behaves on images it has never seen — including images
            that are not factory parts at all.
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <Card title="1. Upload or Generate a Test Image">
              <div className="space-y-4">
                <div>
                  <label className="mb-1 block text-[12px] font-semibold text-[var(--color-ink-faint)]">
                    Upload your own image (PNG or JPEG):
                  </label>
                  <input
                    type="file"
                    accept="image/png,image/jpeg"
                    className="field"
                    onChange={(e) => upload(e.target.files?.[0])}
                    disabled={uploading}
                  />
                  {uploading && <Spinner label="Uploading..." />}
                </div>
                <div>
                  <label className="mb-1 block text-[12px] font-semibold text-[var(--color-ink-faint)]">
                    Optional note (stored with the image):
                  </label>
                  <input
                    className="field"
                    placeholder="e.g. photo from the line, random web image…"
                    value={uploadNote}
                    onChange={(e) => setUploadNote(e.target.value)}
                  />
                </div>

                <div className="border-t border-[var(--color-edge)] pt-3">
                  <label className="mb-1 block text-[12px] font-semibold text-[var(--color-ink-faint)]">
                    …or generate synthetic test images:
                  </label>
                  <div className="flex gap-2">
                    <select className="field" value={genKind} onChange={(e) => setGenKind(e.target.value as typeof genKind)}>
                      <option value="mixed">Mixed (both kinds)</option>
                      <option value="variation">Twisted factory images</option>
                      <option value="nonfactory">Non-factory images</option>
                    </select>
                    <button className="btn" onClick={generate} disabled={generating}>
                      {generating ? "Generating…" : "Generate 6"}
                    </button>
                  </div>
                  <p className="mt-2 text-[11.5px] text-[var(--color-ink-faint)]">
                    “Twisted factory images” are real archive images with brightness, rotation, flip, blur, noise or
                    contrast changes. “Non-factory images” are synthetic faces, cars, trees, phones and random noise
                    that look nothing like the training data. These are robustness probes only — not real factory
                    images and not labelled ground truth.
                  </p>
                </div>
              </div>
            </Card>

            <Card title="2. Pick a Test Image" subtitle={externalInfo.data ? `${externalInfo.data.count} stored test image(s)` : undefined}>
              {externalList.loading ? (
                <Spinner />
              ) : entries.length === 0 ? (
                <Empty>Nothing here yet. Upload an image or generate a set above.</Empty>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {entries.map((entry: ExternalImageEntry) => (
                    <div key={entry.id} className="relative">
                      <button
                        onClick={() => runExternal(entry.id)}
                        title={`${entry.source === "upload" ? `upload: ${entry.original_name}` : entry.description || "generated"}${entry.note ? ` — ${entry.note}` : ""}`}
                        className={`h-[64px] w-[64px] overflow-hidden rounded border-2 ${
                          prediction?.external?.id === entry.id ? "border-[var(--color-accent)]" : "border-[var(--color-edge)]"
                        }`}
                      >
                        <img src={api.externalImageUrl(entry.id)} alt={entry.original_name} loading="lazy" className="h-full w-full object-cover" />
                      </button>
                      <button
                        className="absolute -right-1.5 -top-1.5 grid h-[18px] w-[18px] place-items-center rounded-full border border-[var(--color-edge)] bg-[var(--color-void)] text-[10px] text-[var(--color-ink-faint)] hover:text-[var(--color-bad)]"
                        title="Delete this test image"
                        onClick={() => remove(entry.id)}
                      >
                        ✕
                      </button>
                      <div className="mt-0.5 text-center text-[9.5px] uppercase tracking-wide text-[var(--color-ink-faint)]">
                        {entry.source === "upload" ? "upload" : "generated"}
                      </div>
                    </div>
                  ))}
                </div>
              )}
              <div className="mt-3 flex items-center gap-2 text-[11px] text-[var(--color-ink-faint)]">
                <Badge tone="assumed">test-only</Badge>
                Never used for training · deleted images are removed permanently
              </div>
            </Card>
          </div>

          <Card title="3. Result">
            {loading && isExternal ? (
              <Spinner label="AI is checking..." />
            ) : error && isExternal ? (
              <ErrorBox message={error} />
            ) : !prediction?.external || !isExternal ? (
              <Empty>Pick a test image to see the result here.</Empty>
            ) : (
              <ResultPanel
                prediction={prediction}
                imageUrl={api.externalImageUrl(prediction.external.id)}
                external
              />
            )}
          </Card>

          {isExternal && prediction?.external && (
            <Card title="👨‍🔧 Review">
              <FeedbackBar
                findingId={`external-inspection:${prediction.external.id}`}
                findingKind="external_inspection"
                findingTitle={`External image → ${prediction.label} (${pct(prediction.confidence * 100, 1)})`}
                payload={{
                  external_id: prediction.external.id,
                  source: prediction.external.source,
                  label: prediction.label,
                  confidence: prediction.confidence,
                  uncertain: prediction.uncertain,
                }}
              />
            </Card>
          )}
        </div>
      )}

      {tab === "training" && prediction && !isExternal && (
        <Card title="👨‍🔧 Review">
          <FeedbackBar
            findingId={`inspection:${prediction.specimen}`}
            findingKind="inspection"
            findingTitle={`${prediction.specimen} → ${prediction.label} (${pct(prediction.confidence * 100, 1)})`}
            payload={{
              specimen: prediction.specimen,
              label: prediction.label,
              confidence: prediction.confidence,
              uncertain: prediction.uncertain,
            }}
          />
        </Card>
      )}
    </div>
  );
}
