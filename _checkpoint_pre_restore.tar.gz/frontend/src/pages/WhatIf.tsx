import { useState } from "react";
import { Card, Empty, Spinner } from "../components/ui";
import { api, getActiveDataset, type ScenarioResult } from "../lib/api";
import { int, money, pct, useApi } from "../lib/hooks";

type Kind = "capacity_change" | "processing_time_change";

export default function WhatIf() {
  const options = useApi(() => api.simulationOptions(), []);

  const [kind, setKind] = useState<Kind>("capacity_change");
  const [station, setStation] = useState("cell4");
  const [capacityDelta, setCapacityDelta] = useState(1);
  const [timeFactor, setTimeFactor] = useState(0.9);
  
  const [result, setResult] = useState<ScenarioResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const run = async () => {
    setBusy(true);
    setError(null);
    try {
      const spec = {
        model_key: getActiveDataset(),
        name: "Test Scenario",
        kind,
        station,
        capacity_delta: kind === "capacity_change" ? capacityDelta : 0,
        time_factor: kind === "processing_time_change" ? timeFactor : 1,
        demand_factor: 1,
        replications: 1,
      };
      const res = await api.runScenario(spec, null);
      setResult(res);
    } catch (err) {
      setError((err as Error).message);
      setResult(null);
    } finally {
      setBusy(false);
    }
  };

  const comparisons = result?.comparisons ?? [];
  const utilRow = comparisons.find((r) => r.metric === "utilization" && r.station === station);
  const queueRow = comparisons.find((r) => r.metric === "queue_mean" && r.station === station);

  return (
    <div className="space-y-6 max-w-5xl">
      <header>
        <h1 className="text-[24px] font-bold tracking-tight">What If?</h1>
        <p className="mt-2 text-[14px] text-[var(--color-ink-dim)]">
          Test what happens to production if you make changes to the factory.
        </p>
      </header>

      <div className="grid gap-6 md:grid-cols-[300px_1fr]">
        <Card title="What do you want to change?">
          <div className="space-y-4">
            <div>
              <label className="text-[12px] font-semibold text-[var(--color-ink-faint)] block mb-1">Station:</label>
              <select className="field w-full" value={station} onChange={(e) => setStation(e.target.value)}>
                {(options.data?.stations ?? []).map((s: any) => (
                  <option key={s.key} value={s.key}>{s.label}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[12px] font-semibold text-[var(--color-ink-faint)] block mb-1">Change:</label>
              <select className="field w-full" value={kind} onChange={(e) => setKind(e.target.value as Kind)}>
                <option value="capacity_change">Capacity</option>
                <option value="processing_time_change">Processing Time</option>
              </select>
            </div>

            <div>
              <label className="text-[12px] font-semibold text-[var(--color-ink-faint)] block mb-1">Amount:</label>
              {kind === "capacity_change" ? (
                <input
                  className="field w-full mono"
                  type="number"
                  min={-3} max={8}
                  value={capacityDelta}
                  onChange={(e) => setCapacityDelta(Number(e.target.value))}
                />
              ) : (
                <div className="flex gap-2 items-center">
                  <input
                    className="field w-full"
                    type="range"
                    min={0.5} max={1.5} step={0.05}
                    value={timeFactor}
                    onChange={(e) => setTimeFactor(Number(e.target.value))}
                  />
                  <span className="mono text-[13px]">{timeFactor}x</span>
                </div>
              )}
            </div>

            <button className="btn btn-primary w-full mt-2" onClick={run} disabled={busy}>
              {busy ? "Running..." : "Run Simulation"}
            </button>

            <p className="text-[11.5px] leading-snug text-[var(--color-ink-faint)]">
              The computer creates a virtual production line, sends parts through the stations, lets them wait when a
              station is busy, and measures what changes. Results are advisory.
            </p>
            
            {error && <div className="text-[12px] text-[var(--color-bad)] mt-2">{error}</div>}
          </div>
        </Card>

        <div>
          {busy ? (
            <Card title="Running Simulation">
              <Spinner label="Calculating what happens..." />
            </Card>
          ) : !result ? (
            <Card title="Results">
              <Empty>Select a change and run the simulation to see results.</Empty>
            </Card>
          ) : (
            <div className="space-y-6">
              <Card title="CURRENT vs AFTER CHANGE">
                <div className="grid gap-6 sm:grid-cols-2">
                  <div className="bg-[var(--color-surface)] p-4 rounded-md border border-[var(--color-edge)]">
                    <h3 className="font-semibold text-[var(--color-ink-dim)] mb-4">Production (Parts)</h3>
                    <div className="flex justify-between text-[16px] font-mono">
                      <span>{int(result.summary.baseline_released_parts ?? 0)}</span>
                      <span>→</span>
                      <span className="text-[var(--color-accent)]">{int(result.summary.completed_parts ?? 0)}</span>
                    </div>
                  </div>
                  
                  {utilRow && (
                    <div className="bg-[var(--color-surface)] p-4 rounded-md border border-[var(--color-edge)]">
                      <h3 className="font-semibold text-[var(--color-ink-dim)] mb-4">Target Station Busy %</h3>
                      <div className="flex justify-between text-[16px] font-mono">
                        <span>{pct((utilRow.current ?? 0) * 100, 1)}</span>
                        <span>→</span>
                        <span className={((utilRow.delta ?? 0) < 0) ? "text-[var(--color-ok)]" : "text-[var(--color-warn)]"}>
                          {pct((utilRow.simulated ?? 0) * 100, 1)}
                        </span>
                      </div>
                    </div>
                  )}

                  {queueRow && (
                    <div className="bg-[var(--color-surface)] p-4 rounded-md border border-[var(--color-edge)]">
                      <h3 className="font-semibold text-[var(--color-ink-dim)] mb-4">Target Station Queue</h3>
                      <div className="flex justify-between text-[16px] font-mono">
                        <span>{int(queueRow.current ?? 0)}</span>
                        <span>→</span>
                        <span className={((queueRow.delta ?? 0) < 0) ? "text-[var(--color-ok)]" : "text-[var(--color-warn)]"}>
                          {int(queueRow.simulated ?? 0)}
                        </span>
                      </div>
                    </div>
                  )}
                </div>

                <div className="mt-6 border-t border-[var(--color-edge)] pt-4">
                  <h3 className="font-semibold mb-2">Economic Impact</h3>
                  {!result.economics.available ? (
                    <p className="text-[14px] text-[var(--color-warn)]">
                      Provide a rate card to calculate monetary impact — the datasets contain no costs or prices,
                      so this app will not invent them.
                    </p>
                  ) : (
                    <span className="mono text-[18px] font-semibold text-[var(--color-accent)]">
                      {money(result.economics.total ?? null, result.economics.currency ?? "USD")}
                    </span>
                  )}
                </div>
                
                <details className="mt-4 border-t border-[var(--color-edge)] pt-4 text-[13px] text-[var(--color-ink-dim)] cursor-pointer">
                  <summary className="font-semibold text-[var(--color-ink)]">How this was calculated ▾</summary>
                  <div className="mt-2 space-y-2">
                    <p><strong>Engine:</strong> Discrete-event simulation (multi-server queue logic).</p>
                    <p><strong>Baseline:</strong> The simulation baseline is matched against the actual exported values before applying your changes.</p>
                  </div>
                </details>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
