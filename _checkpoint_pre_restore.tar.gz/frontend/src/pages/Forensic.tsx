import { useEffect, useState } from "react";
import Timeline from "../components/Timeline";
import { Card, Empty, ErrorBox, EvidenceList, FeedbackBar, Spinner, Stat, Bullets } from "../components/ui";
import { api } from "../lib/api";
import { num, pct, useApi } from "../lib/hooks";

export default function Forensic() {
  const cases = useApi(() => api.cases(), []);
  const [caseId, setCaseId] = useState<string>("group:congested");
  const detail = useApi(() => api.case(caseId), [caseId]);
  const [feedbackKey, setFeedbackKey] = useState(0);

  useEffect(() => {
    if (cases.data?.cases?.length && !cases.data.cases.some((c) => c.case_id === caseId)) {
      setCaseId(cases.data.cases[0].case_id);
    }
  }, [cases.data, caseId]);

  const forensicCase = detail.data;
  const first = forensicCase?.first_divergence ?? null;

  return (
    <div className="space-y-6 max-w-5xl">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-[24px] font-bold tracking-tight">Find the Problem</h1>
          <p className="mt-2 text-[14px] text-[var(--color-ink-dim)]">
            Investigate production issues by tracing where the problem first appeared and how it connects to other stations.
          </p>
        </div>
        <select className="field min-w-[300px]" value={caseId} onChange={(e) => setCaseId(e.target.value)}>
          {(cases.data?.cases ?? []).map((item) => (
            <option key={item.case_id} value={item.case_id}>
              {item.label.replace("Forensic Case", "Problem Investigation")}
            </option>
          ))}
        </select>
      </header>

      {cases.loading || detail.loading ? (
        <Spinner label="Loading investigation data..." />
      ) : cases.error ? (
        <ErrorBox message={cases.error} onRetry={cases.reload} />
      ) : detail.error ? (
        <ErrorBox message={detail.error} onRetry={detail.reload} />
      ) : !forensicCase ? (
        <Empty>No problem selected.</Empty>
      ) : (
        <div className="space-y-6">
          <Card title="1. Problem Investigation">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <Stat
                label="First Unusual Change"
                value={first ? first.label : "None found"}
                tone="bad"
              />
              <Stat
                label="Assembled parts"
                value={forensicCase.outcome?.delta_pct !== undefined ? pct(forensicCase.outcome.delta_pct, 2) : "—"}
                tone={(forensicCase.outcome?.delta_pct ?? 0) < 0 ? "bad" : "ok"}
                hint={`Selection vs average`}
              />
              <Stat
                label="Stations affected"
                value={String(forensicCase.co_occurring?.length ?? 0)}
              />
              <Stat
                label="Confidence"
                value={num(forensicCase.confidence * 100, 0) + "%"}
                tone={forensicCase.confidence >= 0.7 ? "ok" : forensicCase.confidence >= 0.4 ? "warn" : "bad"}
              />
            </div>
          </Card>

          <Card title="2. Where it appears (Timeline)">
            <Timeline events={forensicCase.timeline} firstStation={first?.station} />
          </Card>

          <Card title="3. What We Found">
            <p className="mb-4 text-[14px] font-medium text-[var(--color-warn)]">
              Possible Reason: Strong connection found at {first ? first.label : "multiple stations"}.
            </p>
            <EvidenceList items={forensicCase.evidence} />
            
            <details className="mt-4 border-t border-[var(--color-edge)] pt-4 text-[13px] text-[var(--color-ink-dim)] cursor-pointer">
              <summary className="font-semibold text-[var(--color-ink)]">How this was calculated ▾</summary>
              <div className="mt-2 space-y-2">
                <p><strong>Algorithm:</strong> Process-route order and partial correlation.</p>
                <p><strong>Method:</strong> It traces unusual changes (using robust Z-scores or Cohen's d) along the documented flow of the factory.</p>
                <p><strong>Note:</strong> This shows statistical association, not absolute proof of causation.</p>
              </div>
            </details>
          </Card>

          <div className="grid gap-4 md:grid-cols-2">
            <Card title="What We Don't Know">
              <Bullets items={forensicCase.limitations} />
            </Card>
            
            <Card title="👨‍🔧 Review">
              <p className="mb-4 text-[14px] text-[var(--color-ink-dim)]">Was this finding useful?</p>
              <FeedbackBar
                key={`${caseId}-${feedbackKey}`}
                findingId={`forensic:${forensicCase.case_id}`}
                findingKind="forensic_case"
                findingTitle={`${forensicCase.label}`}
                payload={{
                  case_id: forensicCase.case_id,
                  confidence: forensicCase.confidence,
                }}
                onDone={() => setFeedbackKey((k) => k + 1)}
              />
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}
