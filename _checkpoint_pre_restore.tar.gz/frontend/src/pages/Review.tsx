import { Badge, Card, Empty, ErrorBox, Spinner, Stat } from "../components/ui";
import { api } from "../lib/api";
import { int, useApi } from "../lib/hooks";

const DECISION_META: Record<string, { label: string; tone: "ok" | "bad" | "warn" }> = {
  confirmed: { label: "✓ Confirmed", tone: "ok" },
  rejected: { label: "✕ Rejected", tone: "bad" },
  needs_review: { label: "⚠ Needs review", tone: "warn" },
};

export default function Review() {
  const summary = useApi(() => api.reviewSummary(), []);
  const feedback = useApi(() => api.feedbackList(100), []);

  const counts = summary.data?.counts ?? {};

  return (
    <div className="space-y-6 max-w-5xl">
      <header>
        <h1 className="text-[24px] font-bold tracking-tight">Review</h1>
        <p className="mt-2 text-[14px] text-[var(--color-ink-dim)]">
          History of all decisions and feedback recorded in the system.
        </p>
      </header>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Total Decisions" value={int(summary.data?.total ?? 0)} />
        <Stat label="Confirmed" value={int(counts.confirmed ?? 0)} tone="ok" />
        <Stat label="Rejected" value={int(counts.rejected ?? 0)} tone="bad" />
        <Stat label="Needs Review" value={int(counts.needs_review ?? 0)} tone="warn" />
      </div>

      <Card title="Decision History">
        {feedback.loading ? (
          <Spinner label="Loading history..." />
        ) : feedback.error ? (
          <ErrorBox message={feedback.error} onRetry={feedback.reload} />
        ) : feedback.data?.length ? (
          <div className="space-y-4">
            {feedback.data.map((item) => {
              const meta = DECISION_META[item.decision] ?? DECISION_META.needs_review;
              return (
                <div key={item.id} className="bg-[var(--color-surface)] p-4 rounded-md border border-[var(--color-edge)]">
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                    <Badge tone={meta.tone}>{meta.label}</Badge>
                    <span className="text-[12px] text-[var(--color-ink-dim)]">
                      {new Date(item.created_at).toLocaleString()}
                    </span>
                  </div>
                  
                  <div className="text-[14px] font-medium">{item.finding_title}</div>
                  
                  {item.note && (
                    <p className="mt-2 text-[13px] italic text-[var(--color-ink-dim)] bg-[rgba(0,0,0,0.02)] p-2 rounded">
                      "{item.note}"
                    </p>
                  )}
                  
                  <details className="mt-3 text-[12px] text-[var(--color-ink-dim)] cursor-pointer">
                    <summary className="font-semibold text-[var(--color-ink)] hover:underline">Data Details ▾</summary>
                    <pre className="mt-2 max-h-[150px] overflow-auto rounded bg-black/5 p-2 text-[11px]">
                      {JSON.stringify(item.payload, null, 2)}
                    </pre>
                  </details>
                </div>
              );
            })}
          </div>
        ) : (
          <Empty>No engineer decisions recorded yet. Review a finding from any analysis page.</Empty>
        )}
      </Card>
    </div>
  );
}
