import { Link } from "react-router-dom";
import { Badge, Card, ErrorBox, Spinner } from "../components/ui";
import { api } from "../lib/api";
import { int, pct } from "../lib/hooks";
import { useApi } from "../lib/hooks";
import { Term } from "../components/Glossary";

/**
 * Beginner-first landing page.
 *
 * Answers only: what is happening? why? how serious? what can I test?
 * Every number comes from an API; when the data cannot support a number the
 * card says why instead of showing a zero or a fake figure.
 */
export default function Dashboard() {
  const overview = useApi(() => api.overview(), []);
  const production = useApi(() => api.productionSnapshot(), []);
  const anomalies = useApi(() => api.anomalies(undefined, 5), []);

  if (overview.loading && !overview.data) return <Spinner label="Loading..." />;
  if (overview.error) return <ErrorBox message={overview.error} onRetry={overview.reload} />;

  const snap = production.data;
  const top = snap?.bottleneck_candidates?.[0];
  const vision = (overview.data?.datasets ?? []).find((d) => d.kind === "images");
  const imageCount = vision?.rows ?? 0;
  const topAnomaly = anomalies.data?.top?.[0];
  const economicNotCalculable = (overview.data?.capabilities?.economic_impact ?? true) === false;

  // A simple status light: utilisation of the ranked constraint decides it.
  const statusTone = !snap ? "muted" : (top?.utilization ?? 0) >= 0.9 ? "bad" : (top?.utilization ?? 0) >= 0.75 ? "warn" : "ok";
  const statusText =
    statusTone === "bad" ? "Under pressure" : statusTone === "warn" ? "Busy in places" : statusTone === "ok" ? "Normal" : "Measuring…";

  return (
    <div className="space-y-6 max-w-5xl">
      {/* Hero: tell a first-time user what this is and what to press. */}
      <section className="panel fade-in p-6">
        <h1 className="text-[26px] font-bold tracking-tight">🏭 Factory Time Machine</h1>
        <p className="mt-2 max-w-2xl text-[14px] leading-relaxed text-[var(--color-ink-dim)]">
          Understand factory problems in simple steps: check a product image, find where a problem started, see how it
          affects production, test what a change would do.
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          <Link className="btn btn-primary" to="/inspection">👁️ Inspect a product</Link>
          <Link className="btn" to="/forensic">🔎 Investigate a problem</Link>
          <Link className="btn" to="/whatif">🧪 What if we change it?</Link>
        </div>
        <p className="mt-3 text-[11.5px] text-[var(--color-ink-faint)]">
          Everything here is analysis and advice only — the tool controls no machines. Based on{" "}
          {int(imageCount)} labelled product images and {(overview.data?.datasets ?? []).filter((d) => d.kind === "simulation").reduce((a, d) => a + d.rows, 0).toLocaleString()} simulated production runs.
        </p>
      </section>

      {/* Status: one light + two simple numbers. */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <Card title="🟢 Factory Status">
          <div className="flex items-center gap-3">
            <span
              className={`h-3.5 w-3.5 rounded-full ${
                statusTone === "bad" ? "bg-[var(--color-bad)]" : statusTone === "warn" ? "bg-[var(--color-warn)]" : statusTone === "ok" ? "bg-[var(--color-ok)]" : "bg-[var(--color-ink-faint)]"
              }`}
            />
            <span className="text-[20px] font-bold">{statusText}</span>
          </div>
          <p className="mt-2 text-[12px] leading-snug text-[var(--color-ink-faint)]">
            Based on how busy the busiest station is across the simulated production runs.
          </p>
        </Card>

        <Card title="✅ Quality (AI checks)">
          <div className="mono text-[22px] font-semibold">{int(imageCount)} images</div>
          <p className="mt-1 text-[12px] leading-snug text-[var(--color-ink-faint)]">
            Trained to spot 5 surface conditions: normal, crack, hole, rust, scratch.
          </p>
          <div className="mt-3">
            <Link className="btn" to="/inspection">Check a product</Link>
          </div>
        </Card>

        <Card title="🚧 Busiest station">
          <div className="text-[20px] font-bold">{top?.label ?? "—"}</div>
          <div className="mono mt-1 text-[13px] text-[var(--color-ink-dim)]">
            {top?.utilization ? (
              <>
                <Term name="utilization">{pct(top.utilization * 100, 1)}</Term> busy
              </>
            ) : (
              "—"
            )}
          </div>
          <p className="mt-2 text-[12px] leading-snug text-[var(--color-ink-faint)]">
            {top?.utilization && top.utilization >= 0.9
              ? "This station is nearly always occupied — it is likely limiting the whole line."
              : "No station is at full saturation in the simulated runs."}
          </p>
          <div className="mt-3">
            <Link className="btn" to="/production">See details</Link>
          </div>
        </Card>
      </div>

      {/* Main finding: plain language, one sentence, with a next step. */}
      <Card title="🔎 Main Finding" subtitle="What the data says is most unusual right now">
        {anomalies.loading ? (
          <Spinner label="Looking for unusual patterns..." />
        ) : topAnomaly ? (
          <div className="space-y-3">
            <p className="text-[15px] leading-relaxed">
              One simulated production run ({int(topAnomaly.run_index)}) looks very different from the rest:{" "}
              {topAnomaly.drivers.slice(0, 2).map((d: { feature: string; direction: string }, i: number) => (
                <span key={i}>
                  {i > 0 && " and "}
                  <strong>{d.feature.replace(/_/g, " ")}</strong> was unusually {d.direction}
                </span>
              ))}
              .
            </p>
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone="warn">statistically unusual, not a confirmed fault</Badge>
              <Link className="btn btn-primary" to="/forensic">Investigate →</Link>
            </div>
          </div>
        ) : (
          <p className="text-[14px] text-[var(--color-ink-dim)]">
            No unusual production runs stand out in the data.
          </p>
        )}
      </Card>

      {/* Money: honest gate, one line. */}
      {economicNotCalculable && (
        <Card title="💰 Money Impact">
          <p className="text-[14px] leading-relaxed text-[var(--color-ink-dim)]">
            The datasets contain <strong>no costs or prices</strong>, so the app cannot calculate money impact by
            itself. Add your own cost rates (a <Term name="rate card">rate card</Term>) on the What-If page and it
            will compute advisory figures from the measured quantities.
          </p>
          <div className="mt-3">
            <Link className="btn" to="/whatif">Add a rate card on the What-If page</Link>
          </div>
        </Card>
      )}

      <details className="cursor-pointer text-[13px] text-[var(--color-ink-dim)]">
        <summary className="font-semibold text-[var(--color-ink)]">How this works ▾</summary>
        <div className="mt-2 space-y-2 leading-relaxed">
          <p>
            This app is built on two supplied datasets: {int(imageCount)} labelled product images (for the AI
            inspector) and exported results from discrete-event <Term name="discrete-event simulation">factory simulations</Term>{" "}
            (for everything production-related).
          </p>
          <p>
            The image checker is a <Term name="cnn">CNN</Term>. Unusual production runs are found with{" "}
            <Term name="pca">PCA</Term> + <Term name="mahalanobis">Mahalanobis distance</Term>. Station pressure is a
            weighted score of <Term name="utilization">utilisation</Term>, <Term name="queue">queue</Term> length and
            capacity. The two datasets share no identifier, so defect-to-station links are only ever declared
            assumptions.
          </p>
          <p className="text-[var(--color-ink-faint)]">
            Full detail lives in <span className="mono">SYSTEM_EXPLANATION.md</span> and{" "}
            <span className="mono">ALGORITHM_REFERENCE.md</span> in the project root.
          </p>
        </div>
      </details>
    </div>
  );
}
