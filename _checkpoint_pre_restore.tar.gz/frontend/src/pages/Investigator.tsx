import { useState } from "react";
import { Badge, Bullets, Card, Empty, ErrorBox, Spinner } from "../components/ui";
import { api, type AINarrative } from "../lib/api";
import { num, useApi } from "../lib/hooks";

const EXAMPLE_QUESTIONS = [
  "Which station is slowing down the factory?",
  "Why did the factory produce fewer parts this time?",
  "What happens if we speed up Cell 4?",
  "Where did the problem start?",
];

export default function Investigator() {
  const status = useApi(() => api.aiStatus(), []);

  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState<AINarrative | null>(null);
  const [asking, setAsking] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const ask = async (text?: string) => {
    const value = (text ?? question).trim();
    if (!value) return;
    setAsking(true);
    setError(null);
    try {
      const result = await api.aiAsk(value, "overview", null);
      setAnswer(result);
      setQuestion(value);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setAsking(false);
    }
  };

  const renderFinding = (payload: AINarrative) => (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Badge tone={payload.source === "llm" ? "info" : "muted"}>
          {payload.source === "llm" ? "AI Powered" : "Basic Rules Engine"}
        </Badge>
        <span className="text-[12px] text-[var(--color-ink-dim)] ml-auto">
          Confidence: {num(payload.finding.confidence * 100, 0)}%
        </span>
      </div>

      <p className="text-[14px] leading-relaxed text-[var(--color-ink)]">{payload.finding.finding}</p>

      {payload.finding.recommendation && (
        <div className="rounded-lg border border-[var(--color-edge)] bg-[rgba(56,189,248,0.05)] p-4">
          <div className="font-semibold mb-2">Recommendation</div>
          <p className="text-[13px] leading-relaxed text-[var(--color-ink-dim)]">{payload.finding.recommendation}</p>
        </div>
      )}

      {payload.finding.evidence?.length > 0 && (
        <div>
          <div className="font-semibold text-[13px] mb-2">Evidence</div>
          <Bullets items={payload.finding.evidence} />
        </div>
      )}
      
      <details className="mt-4 border-t border-[var(--color-edge)] pt-4 text-[13px] text-[var(--color-ink-dim)] cursor-pointer">
        <summary className="font-semibold text-[var(--color-ink)]">How this works ▾</summary>
        <div className="mt-2 space-y-2">
          <p><strong>System:</strong> The AI model explains and summarizes but does not compute numbers itself.</p>
          <p><strong>Safety:</strong> Every number it receives was produced by the backend's deterministic code.</p>
          {status.data?.llm_enabled === false && (
             <p className="text-[var(--color-bad)]"><strong>Note:</strong> API Key missing, running on basic rules engine.</p>
          )}
        </div>
      </details>
    </div>
  );

  return (
    <div className="space-y-6 max-w-4xl">
      <header>
        <h1 className="text-[24px] font-bold tracking-tight">AI Help</h1>
        <p className="mt-2 text-[14px] text-[var(--color-ink-dim)]">
          Ask the AI assistant anything about the factory's performance.
        </p>
      </header>

      <div className="grid gap-6 md:grid-cols-[300px_1fr]">
        <Card title="Ask a Question">
          <textarea
            className="field w-full h-[100px] resize-none mb-3"
            placeholder="Type your question here..."
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
          />
          <button className="btn btn-primary w-full" onClick={() => ask()} disabled={asking || !question.trim()}>
            {asking ? "Thinking..." : "Ask AI"}
          </button>
          
          <div className="mt-6">
            <h3 className="text-[13px] font-semibold mb-3">Example Questions:</h3>
            <div className="space-y-2">
              {EXAMPLE_QUESTIONS.map((item) => (
                <button 
                  key={item} 
                  className="block w-full text-left text-[13px] p-2 rounded-md hover:bg-[var(--color-surface)] border border-transparent hover:border-[var(--color-edge)] transition-colors text-[var(--color-ink-dim)]"
                  onClick={() => ask(item)}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        </Card>

        <div className="space-y-4">
          {error && <ErrorBox message={error} />}

          <Card title="AI Response">
            {asking ? (
              <Spinner label="The AI is reviewing the factory data..." />
            ) : answer ? (
              renderFinding(answer)
            ) : (
              <Empty>Ask a question to see the AI's analysis.</Empty>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
