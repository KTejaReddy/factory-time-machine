import PropagationGraph from "../components/PropagationGraph";
import { Badge, Card, ErrorBox, Spinner } from "../components/ui";
import { api } from "../lib/api";
import { useApi } from "../lib/hooks";

export default function Propagation() {
  const graph = useApi(() => api.propagation(), []);

  return (
    <div className="space-y-6 max-w-7xl">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-[24px] font-bold tracking-tight">Problem Flow</h1>
          <p className="mt-2 text-[14px] text-[var(--color-ink-dim)]">
            See how problems spread through the factory.
          </p>
        </div>
        <div className="flex gap-2">
          {graph.data && <Badge tone="info">{graph.data.edges.length} connections</Badge>}
        </div>
      </header>

      {graph.loading ? (
        <Spinner label="Loading the problem flow..." />
      ) : graph.error ? (
        <ErrorBox message={graph.error} onRetry={graph.reload} />
      ) : graph.data ? (
        <div className="space-y-6">
          <Card title="How Problems Spread">
            <div className="flex items-center gap-4 justify-center text-[14px] font-medium text-[var(--color-ink-dim)] bg-[var(--color-surface)] py-4 rounded-md border border-[var(--color-edge)]">
              <span>Process Problem</span>
              <span>→</span>
              <span>Product Defect</span>
              <span>→</span>
              <span>High WIP</span>
              <span>→</span>
              <span>Bottleneck</span>
              <span>→</span>
              <span className="text-[var(--color-bad)]">Production Loss</span>
            </div>
            
            <div className="mt-6">
              <PropagationGraph
                nodes={graph.data.nodes}
                edges={graph.data.edges}
                legend={graph.data.legend}
                notice={graph.data.linkage_notice}
              />
            </div>
          </Card>

          <Card title="What We Don't Know">
            <ul className="list-disc list-inside text-[13px] text-[var(--color-ink-dim)] space-y-1">
              {graph.data.limitations?.map((limitation: string, idx: number) => (
                <li key={idx}>{limitation}</li>
              ))}
            </ul>
            <details className="mt-4 border-t border-[var(--color-edge)] pt-4 text-[13px] text-[var(--color-ink-dim)] cursor-pointer">
              <summary className="font-semibold text-[var(--color-ink)]">How this was calculated ▾</summary>
              <div className="mt-2 space-y-2">
                <p><strong>Algorithm:</strong> Network graph using partial correlations.</p>
                <p><strong>Flow Direction:</strong> From the documented physical route of the factory.</p>
                <p><strong>Data Used:</strong> Only actual measured data from the simulation exports is shown as solid lines.</p>
              </div>
            </details>
          </Card>
        </div>
      ) : null}
    </div>
  );
}
