import { BrowserRouter, Route, Routes } from "react-router-dom";
import Layout from "./components/Layout";
import Dashboard from "./pages/Dashboard";
import Datasets from "./pages/Datasets";
import Forensic from "./pages/Forensic";
import Inspection from "./pages/Inspection";
import Investigator from "./pages/Investigator";
import NotFound from "./pages/NotFound";
import Production from "./pages/Production";
import Propagation from "./pages/Propagation";
import Review from "./pages/Review";
import WhatIf from "./pages/WhatIf";

export default function App() {
  // Opting into the v7 behaviour flags keeps the console free of the router's
  // deprecation warnings, which matters because a clean console is how the audit
  // verifies that no page is silently erroring.
  return (
    <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/inspection" element={<Inspection />} />
          <Route path="/forensic" element={<Forensic />} />
          <Route path="/propagation" element={<Propagation />} />
          <Route path="/production" element={<Production />} />
          <Route path="/whatif" element={<WhatIf />} />
          <Route path="/investigator" element={<Investigator />} />
          <Route path="/review" element={<Review />} />
          <Route path="/datasets" element={<Datasets />} />
          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
