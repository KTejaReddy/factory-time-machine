import { useEffect, useState } from "react";
import { NavLink, Outlet } from "react-router-dom";
import { api, type ProcessingStatus } from "../lib/api";
import { Badge } from "./ui";

const NAV = [
  { to: "/", label: "Overview", icon: "🏠", end: true },
  { to: "/inspection", label: "Inspect", icon: "👁️" },
  { to: "/forensic", label: "Investigate", icon: "🔎" },
  { to: "/production", label: "Production", icon: "🏭" },
  { to: "/propagation", label: "Problem Flow", icon: "🕸️" },
  { to: "/whatif", label: "What-If", icon: "🧪" },
  { to: "/investigator", label: "AI Help", icon: "💬" },
  { to: "/review", label: "Review", icon: "👨‍🔧" },
];

function useCatalogStatus() {
  const [status, setStatus] = useState<ProcessingStatus | null>(null);
  const [ai, setAi] = useState<Record<string, any> | null>(null);

  useEffect(() => {
    let alive = true;
    const tick = async () => {
      try {
        const res = await api.status();
        if (alive) setStatus(res.status);
        if (res.status.state === "ready") return true;
      } catch {
        /* backend may still be starting */
      }
      return false;
    };
    void tick();
    const timer = window.setInterval(async () => {
      const done = await tick();
      if (done) window.clearInterval(timer);
    }, 2000);
    api.aiStatus().then((res) => alive && setAi(res)).catch(() => undefined);
    return () => {
      alive = false;
      window.clearInterval(timer);
    };
  }, []);

  return { status, ai };
}

export default function Layout() {
  const { status, ai } = useCatalogStatus();
  const building = status && status.state !== "ready";
  const failed = status?.state === "failed";

  return (
    <div className="flex min-h-screen">
      <aside className="hidden w-[248px] shrink-0 flex-col border-r border-[var(--color-edge)] bg-[rgba(9,14,22,0.7)] px-3 py-4 md:flex">
        <div className="px-2 pb-4">
          <div className="flex items-center gap-2.5">
            <span className="grid h-8 w-8 place-items-center rounded-md border border-[rgba(56,189,248,0.35)] bg-[rgba(56,189,248,0.12)] text-[15px] text-[var(--color-accent)]">
              ⛭
            </span>
            <div className="leading-tight">
              <div className="text-[13.5px] font-semibold tracking-tight">Factory Time Machine</div>
              <div className="text-[10.5px] text-[var(--color-ink-faint)]">manufacturing forensics</div>
            </div>
          </div>
        </div>

        <nav className="flex flex-col gap-0.5">
          {NAV.map((item) => (
            <NavLink key={item.to} to={item.to} end={item.end} className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`}>
              <span className="w-3.5 text-center text-[12px] opacity-80">{item.icon}</span>
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="mt-auto space-y-2 px-2 pt-4">
          <div className="panel-flat p-2.5">
            <div className="text-[10px] font-semibold uppercase tracking-[0.09em] text-[var(--color-ink-faint)]">
              Data pipeline
            </div>
            {building ? (
              <div className="mt-1.5">
                <div className="flex items-center justify-between text-[11.5px] text-[var(--color-warn)]">
                  <span>{status?.step ?? "starting"}</span>
                  <span className="mono">{Math.round((status?.progress ?? 0) * 100)}%</span>
                </div>
                <div className="mt-1 h-1 w-full overflow-hidden rounded-full bg-[rgba(148,163,184,0.16)]">
                  <div className="h-full bg-[var(--color-warn)]" style={{ width: `${(status?.progress ?? 0) * 100}%` }} />
                </div>
              </div>
            ) : failed ? (
              <div className="mt-1.5 text-[11.5px] text-[var(--color-bad)]">{status?.error ?? "failed"}</div>
            ) : (
              <div className="mt-1.5 flex items-center gap-2 text-[11.5px] text-[var(--color-ok)]">
                <span className="h-1.5 w-1.5 rounded-full bg-[var(--color-ok)]" />
                ready
                {status?.seconds ? <span className="mono text-[var(--color-ink-faint)]">{status.seconds.toFixed(1)}s</span> : null}
              </div>
            )}
          </div>
          <div className="panel-flat p-2.5">
            <div className="text-[10px] font-semibold uppercase tracking-[0.09em] text-[var(--color-ink-faint)]">
              AI narrative
            </div>
            <div className="mt-1.5">
              {ai?.llm_enabled ? (
                <Badge tone="info">LLM: {ai?.model}</Badge>
              ) : (
                <Badge tone="muted" title={ai?.reason}>
                  deterministic engine
                </Badge>
              )}
            </div>
          </div>
          <div className="px-0.5 text-[10.5px] leading-snug text-[var(--color-ink-faint)]">
            Advisory only. No equipment, PLC or production line is ever controlled.
          </div>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-[var(--color-edge)] bg-[rgba(7,11,17,0.86)] px-5 py-3 backdrop-blur">
          <div className="md:hidden text-[13px] font-semibold">⛭ Factory Time Machine</div>
          <nav className="flex gap-2 overflow-x-auto md:hidden">
            {NAV.slice(0, 5).map((item) => (
              <NavLink key={item.to} to={item.to} end={item.end} className={({ isActive }) => `btn ${isActive ? "btn-primary" : ""}`}>
                {item.label}
              </NavLink>
            ))}
          </nav>
          <div className="ml-auto flex items-center gap-2">
            {building && <Badge tone="warn">processing datasets…</Badge>}
            {failed && <Badge tone="bad">dataset error</Badge>}
            {status?.state === "ready" && <Badge tone="ok">datasets ready</Badge>}
            <Badge tone="muted" title="Every finding in this tool is advisory; it cannot command machinery.">
              advisory only
            </Badge>
          </div>
        </header>

        <main className="min-w-0 flex-1 px-5 py-5">
          {building && (
            <div className="panel mb-4 p-3 text-[12.5px] text-[var(--color-ink-dim)]">
              Building the analysis caches from the source archives (first run reads {status?.message || "the datasets"}).
              Pages will populate automatically. {status?.step ? <span className="mono"> step: {status.step}</span> : null}
            </div>
          )}
          <Outlet />
        </main>
      </div>
    </div>
  );
}
