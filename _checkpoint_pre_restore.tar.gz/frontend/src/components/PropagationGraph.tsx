import {
  Background,
  Controls,
  Handle,
  MiniMap,
  Position,
  ReactFlow,
  type Edge,
  type Node,
  type NodeProps,
  type ReactFlowInstance,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import { useEffect, useMemo, useRef, useState } from "react";
import type { PropEdge, PropNode } from "../lib/api";
import { num, pct } from "../lib/hooks";
import { Badge, Bullets, Empty, EvidenceList, KeyValue } from "./ui";

interface NodeData extends Record<string, unknown> {
  label: string;
  kind: string;
  status: string;
  utilisation?: number | null;
  queue?: number | null;
  images?: number | null;
}
type FlowNode = Node<NodeData>;

const STAGE_STYLES: Record<string, { border: string; bg: string }> = {
  process: { border: "#2c4060", bg: "rgba(20,32,51,0.96)" },
  state: { border: "rgba(251,191,36,0.55)", bg: "rgba(52,41,18,0.9)" },
  outcome: { border: "rgba(251,113,133,0.55)", bg: "rgba(52,24,31,0.9)" },
  economic: { border: "rgba(148,163,184,0.4)", bg: "rgba(26,32,42,0.9)" },
  defect: { border: "rgba(167,139,250,0.5)", bg: "rgba(35,28,58,0.9)" },
};

function GraphNode({ data, selected }: NodeProps<FlowNode>) {
  const style = STAGE_STYLES[data.kind] ?? STAGE_STYLES.process;
  const classes = ["flow-node", selected ? "selected" : "", data.status === "assumed" ? "assumed" : "", data.status === "unavailable" ? "unavailable" : ""]
    .filter(Boolean)
    .join(" ");
  return (
    <div className={classes} style={{ borderColor: style.border, background: style.bg }}>
      <Handle type="target" position={Position.Left} style={{ background: "#38506f", width: 6, height: 6 }} />
      <div className="text-[11.5px] font-semibold leading-tight">{data.label}</div>
      <div className="mt-1 space-y-0.5 text-[10.5px] text-[var(--color-ink-faint)]">
        {data.utilisation !== undefined && data.utilisation !== null && (
          <div className="mono">util {pct(data.utilisation * 100, 1)}</div>
        )}
        {data.queue !== undefined && data.queue !== null && <div className="mono">queue {num(data.queue, 1)}</div>}
        {data.images !== undefined && data.images !== null && <div className="mono">{num(data.images, 0)} images</div>}
      </div>
      {data.status !== "observed" && (
        <div className="mt-1">
          <span className={`chip ${data.status === "assumed" ? "chip-assumed" : "chip-muted"}`}>{data.status}</span>
        </div>
      )}
      <Handle type="source" position={Position.Right} style={{ background: "#38506f", width: 6, height: 6 }} />
    </div>
  );
}

const nodeTypes = { flow: GraphNode };

/**
 * Hand-authored layout.
 *
 * The process route is documented, so it gets a single left-to-right row and
 * reads exactly like the plant: blanking -> forklift -> pressing -> assembly ->
 * storage -> paint -> quality. The consequence chain hangs *above* the route
 * (it starts from storage), and the vision defect taxonomy sits *below* on its
 * own row. That keeps every edge pointing rightwards or upwards and avoids the
 * hairball a force layout would produce on a graph this sparse.
 */
const COLUMN = 205;
const ROUTE_Y = 250;
const CONSEQUENCE_Y = 30;
const DEFECT_Y = 500;

const LAYOUT: Record<string, { x: number; y: number }> = {
  // documented process route, one row, left to right
  stage_blanking: { x: 0, y: ROUTE_Y },
  stage_logistics: { x: COLUMN, y: ROUTE_Y },
  stage_pressing: { x: COLUMN * 2, y: ROUTE_Y },
  stage_assembly: { x: COLUMN * 3, y: ROUTE_Y },
  state_storage: { x: COLUMN * 4, y: ROUTE_Y },
  stage_paint: { x: COLUMN * 5, y: ROUTE_Y },
  stage_quality: { x: COLUMN * 6, y: ROUTE_Y },

  // consequence chain, above the route and starting at the WIP node
  state_bottleneck: { x: COLUMN * 4, y: CONSEQUENCE_Y },
  outcome_throughput_loss: { x: COLUMN * 5, y: CONSEQUENCE_Y },
  outcome_economic: { x: COLUMN * 6, y: CONSEQUENCE_Y },

  // vision taxonomy, its own row - it shares no key with the route
  defect_normal: { x: 0, y: DEFECT_Y },
  defect_crack: { x: COLUMN, y: DEFECT_Y },
  defect_hole: { x: COLUMN * 2, y: DEFECT_Y },
  defect_rust: { x: COLUMN * 3, y: DEFECT_Y },
  defect_scratch: { x: COLUMN * 4, y: DEFECT_Y },
};

/**
 * Positions for every node, including ones this layout does not know about.
 * Unplaced nodes spill onto a deterministic grid below the graph instead of all
 * stacking on the same coordinate, which would hide them from the engineer.
 */
function layoutNodes(nodes: PropNode[]): Record<string, { x: number; y: number }> {
  const positions: Record<string, { x: number; y: number }> = {};
  const overflow: PropNode[] = [];
  nodes.forEach((node) => {
    const known = LAYOUT[node.id];
    if (known) positions[node.id] = known;
    else overflow.push(node);
  });
  overflow.forEach((node, index) => {
    positions[node.id] = { x: (index % 4) * COLUMN, y: DEFECT_Y + 140 * (Math.floor(index / 4) + 1) };
  });
  return positions;
}

export default function PropagationGraph({
  nodes,
  edges,
  legend,
  notice,
}: {
  nodes: PropNode[];
  edges: PropEdge[];
  legend: Record<string, string>;
  notice: string;
}) {
  const [selected, setSelected] = useState<PropNode | null>(null);
  const [showAssumed, setShowAssumed] = useState(true);
  const [instance, setInstance] = useState<ReactFlowInstance | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const flowNodes: FlowNode[] = useMemo(() => {
    const positions = layoutNodes(nodes);
    return nodes.map((node) => {
        const position = positions[node.id] ?? { x: 0, y: 0 };
        return {
          id: node.id,
          type: "flow",
          position,
          data: {
            label: node.label,
            kind: node.kind,
            status: node.status,
            utilisation: node.metrics?.utilisation_mean ?? node.metrics?.utilisation ?? null,
            queue: node.metrics?.queue_mean ?? null,
            images: node.metrics?.images ?? null,
          },
          selected: selected?.id === node.id,
        } satisfies FlowNode;
      });
  }, [nodes, selected]);

  const flowEdges: Edge[] = useMemo(
    () =>
      edges
        .filter((edge) => showAssumed || edge.status !== "assumed")
        .map((edge) => ({
          id: edge.id,
          source: edge.source,
          target: edge.target,
          animated: edge.status === "observed" && (edge.strength ?? 0) > 0.5,
          label: edge.relation,
          labelStyle: { fill: "#8ea0b8", fontSize: 9.5 },
          labelBgStyle: { fill: "rgba(7,11,17,0.85)" },
          labelBgPadding: [4, 2] as [number, number],
          style: {
            stroke: edge.status === "assumed" ? "#a78bfa" : edge.status === "unavailable" ? "#4b5563" : "#38bdf8",
            strokeWidth: edge.status === "assumed" ? 1.6 : Math.max(1, Math.min(3, Math.abs(edge.strength ?? 0.6) * 3)),
            strokeDasharray: edge.status === "assumed" ? "6 4" : edge.status === "unavailable" ? "2 4" : undefined,
          },
        })),
    [edges, showAssumed],
  );

  const edgeCount = flowEdges.length;

  // React Flow fits the view when it initialises, which can happen before the
  // container has its final size (the browser window decides the height). Without
  // this the graph can start zoomed in with its right-hand nodes cut off, so the
  // view is refitted whenever the node set changes or the container resizes.
  useEffect(() => {
    if (!instance) return;
    const refit = () => instance.fitView({ padding: 0.14 });
    refit();
    const target = containerRef.current;
    if (!target || typeof ResizeObserver === "undefined") return;
    const observer = new ResizeObserver(refit);
    observer.observe(target);
    return () => observer.disconnect();
  }, [instance, flowNodes.length, containerRef]);

  return (
    <div className="grid gap-4 xl:grid-cols-[1fr_360px]">
      <div className="panel overflow-hidden">
        <div className="panel-head">
          <div>
            <div className="panel-title">Failure propagation</div>
            <div className="mt-0.5 text-[11.5px] text-[var(--color-ink-faint)]">
              {flowNodes.length} nodes · {edgeCount} edges · click a node for its supporting data
            </div>
            <div className="mt-0.5 text-[11px] text-[var(--color-ink-faint)]">
              Drag to move · scroll to zoom · the frame button (bottom left) fits the whole route
            </div>
          </div>
          <label className="flex items-center gap-2 text-[11.5px] text-[var(--color-ink-dim)]">
            <input type="checkbox" checked={showAssumed} onChange={(e) => setShowAssumed(e.target.checked)} />
            show assumed edges
          </label>
        </div>
        <div ref={containerRef} className="h-[clamp(420px,60vh,660px)]">
          <ReactFlow
            nodes={flowNodes}
            edges={flowEdges}
            nodeTypes={nodeTypes}
            fitView
            fitViewOptions={{ padding: 0.14 }}
            // The route is intrinsically wide (seven stages in a row). Zooming all
            // the way out to fit it made the labels unreadable, so the floor is set
            // where text is still legible and the graph pans instead.
            minZoom={0.45}
            proOptions={{ hideAttribution: true }}
            onInit={setInstance}
            onNodeClick={(_, node) => setSelected(nodes.find((n) => n.id === node.id) ?? null)}
            onPaneClick={() => setSelected(null)}
          >
            <Background color="#16233a" gap={22} />
            <Controls showInteractive={false} />
            <MiniMap pannable zoomable style={{ background: "#0b111b", border: "1px solid #1e2c41" }} maskColor="rgba(7,11,17,0.7)" nodeColor="#22314a" />
          </ReactFlow>
        </div>
        <div className="border-t border-[var(--color-edge)] p-3 text-[11.5px] leading-relaxed text-[var(--color-ink-faint)]">{notice}</div>
      </div>

      <div className="space-y-4">
        <div className="panel p-4">
          <div className="panel-title">Legend</div>
          <ul className="mt-2.5 space-y-2 text-[12px]">
            {Object.entries(legend).map(([key, value]) => (
              <li key={key} className="flex gap-2.5">
                <span className="mt-1 shrink-0">
                  <Badge tone={key === "observed" ? "info" : key === "assumed" ? "assumed" : "muted"}>{key}</Badge>
                </span>
                <span className="leading-snug text-[var(--color-ink-dim)]">{value}</span>
              </li>
            ))}
          </ul>
        </div>

        {selected ? (
          <div className="panel fade-in">
            <div className="panel-head">
              <div className="panel-title">Node detail</div>
              <Badge tone={selected.status === "observed" ? "info" : selected.status === "assumed" ? "assumed" : "muted"}>
                {selected.status}
              </Badge>
            </div>
            <div className="space-y-3 p-4">
              <div>
                <div className="text-[15px] font-semibold leading-tight">{selected.label}</div>
                <div className="mt-1 flex gap-2">
                  <Badge tone="muted">{selected.kind}</Badge>
                  <Badge tone="muted">domain: {selected.domain}</Badge>
                </div>
              </div>

              <KeyValue
                rows={Object.entries(selected.metrics)
                  .filter(([, value]) => value !== null && value !== undefined && typeof value !== "object")
                  .map(([key, value]) => [
                    key.replace(/_/g, " "),
                    typeof value === "number" ? num(value, 3) : String(value),
                  ])}
              />

              {selected.evidence?.length > 0 && (
                <div>
                  <div className="panel-title mb-1.5">Supporting data</div>
                  <EvidenceList items={selected.evidence} compact />
                </div>
              )}
              {selected.notes?.length > 0 && (
                <div>
                  <div className="panel-title mb-1.5">Notes</div>
                  <Bullets items={selected.notes} tone="faint" />
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="panel p-4">
            <div className="panel-title">Node detail</div>
            <Empty>Select a node in the graph to inspect the evidence behind it.</Empty>
          </div>
        )}
      </div>
    </div>
  );
}
