from fastapi import APIRouter, UploadFile, File, HTTPException
from typing import List
import shutil
import os
from pathlib import Path

router = APIRouter(prefix="/upload", tags=["upload"])
UPLOAD_DIR = Path("data/user_datasets")
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

@router.post("/")
async def upload_dataset(files: List[UploadFile] = File(...)):
    if not files:
        raise HTTPException(status_code=400, detail="No files uploaded")
    
    saved_files = []
    for file in files:
        file_location = UPLOAD_DIR / file.filename
        try:
            with open(file_location, "wb") as buffer:
                shutil.copyfileobj(file.file, buffer)
            saved_files.append(file.filename)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Could not save file {file.filename}: {e}")
            
    return {"message": "Files uploaded successfully", "files": saved_files}
