"""Human-in-the-loop review, dataset linkage assumptions, and AI narrative endpoints."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Body, HTTPException, Query

from ..db import FeedbackItem, LinkageAssumption, insert_row, list_rows, session
from ..schemas import AIQuestion, FeedbackIn, FeedbackOut, LinkageAssumptionIn
from ..services import ai_client, analytics, bottleneck, domain, economics, forensics, simulation
from ..services.catalog import catalog

router = APIRouter(prefix="/api", tags=["operations"])


# ---------------------------------------------------------------------------
# Feedback (engineer review)
# ---------------------------------------------------------------------------
@router.post("/review/feedback", response_model=FeedbackOut)
def submit_feedback(payload: FeedbackIn) -> FeedbackOut:
    row = insert_row(
        FeedbackItem(
            finding_id=payload.finding_id,
            finding_kind=payload.finding_kind,
            finding_title=payload.finding_title[:400],
            payload=__import__("json").dumps(payload.payload, default=str),
            decision=payload.decision,
            note=payload.note[:4000],
            engineer=payload.engineer[:120],
        )
    )
    return FeedbackOut(
        item=row.as_dict(),
        model_retrained=False,
        note=(
            "Stored. This build performs no automatic retraining: nothing in the model pipeline consumes "
            "feedback yet, so no accuracy change should be expected."
        ),
    )


@router.get("/review/feedback")
def list_feedback(limit: int = Query(100, ge=1, le=500)) -> List[Dict[str, Any]]:
    return [row.as_dict() for row in list_rows(FeedbackItem, limit=limit)]


@router.get("/review/summary")
def review_summary() -> Dict[str, Any]:
    items = [row.as_dict() for row in list_rows(FeedbackItem, limit=500)]
    counts = {"confirmed": 0, "rejected": 0, "needs_review": 0}
    for item in items:
        counts[item["decision"]] = counts.get(item["decision"], 0) + 1
    return {
        "total": len(items),
        "counts": counts,
        "kinds": sorted({i["finding_kind"] for i in items}),
        "retraining": {
            "implemented": False,
            "note": (
                "Feedback is stored for auditing and future supervised retraining, but this build does not "
                "retrain any model from it. Claiming otherwise would be false."
            ),
        },
    }


# ---------------------------------------------------------------------------
# Declared dataset linkage
# ---------------------------------------------------------------------------
@router.get("/review/assumptions")
def list_assumptions() -> Dict[str, Any]:
    rows = [row.as_dict() for row in list_rows(LinkageAssumption, limit=200)]
    return {
        "assumptions": rows,
        "linkage": catalog.linkage_report(),
        "note": (
            "These edges are engineer-declared. They are not derived from the data, because the image archive "
            "and the simulation exports share no key."
        ),
    }


def _known_defect_classes() -> List[str]:
    """The classes the archive actually has, in the order the graph prefers."""
    known = set(catalog.vision_classes)
    ordered = [c for c in ("normal", "crack", "hole", "rust", "scratch") if c in known]
    return ordered + sorted(known - set(ordered))


def _known_station_keys() -> List[str]:
    """Every station key across the models, so one model's station is never rejected."""
    keys: List[str] = []
    for model in domain.MODELS.values():
        for station in model.stations:
            if station.key not in keys:
                keys.append(station.key)
    return keys


@router.post("/review/assumptions")
def create_assumption(payload: LinkageAssumptionIn) -> Dict[str, Any]:
    """Record an engineer-declared defect-class -> station link.

    The values are validated against the datasets first. An assumption naming a
    class or station that does not exist cannot be turned into a graph edge, so
    accepting it would only produce a dangling link later (the audit caught exactly
    that with the class 'crazing', which is not one of the archive labels).
    """
    classes = _known_defect_classes()
    stations = _known_station_keys()
    defect_class = payload.defect_class.strip().lower()
    station = payload.station.strip().lower()
    if defect_class not in classes:
        raise HTTPException(
            status_code=422,
            detail=(
                f"'{payload.defect_class}' is not a defect class in the image archive. "
                f"Known classes: {', '.join(classes)}."
            ),
        )
    if station not in stations:
        raise HTTPException(
            status_code=422,
            detail=(
                f"'{payload.station}' is not a station in the simulation exports. "
                f"Known stations: {', '.join(stations)}."
            ),
        )
    row = insert_row(
        LinkageAssumption(
            defect_class=defect_class,
            station=station,
            rationale=payload.rationale[:2000],
            author=payload.author[:120],
            active=payload.active,
        )
    )
    return {
        "assumption": row.as_dict(),
        "note": (
            "Recorded as an assumed edge; it is rendered differently in the graph and cannot be verified "
            "from the data, because the image archive and the simulation exports share no key."
        ),
    }


@router.delete("/review/assumptions/{assumption_id}")
def delete_assumption(assumption_id: int) -> Dict[str, Any]:
    with session() as db:
        row = db.get(LinkageAssumption, assumption_id)
        if row is None:
            raise HTTPException(status_code=404, detail="assumption not found")
        db.delete(row)
    return {"deleted": assumption_id}


# ---------------------------------------------------------------------------
# AI narrative
# ---------------------------------------------------------------------------
def _overview_evidence() -> Dict[str, Any]:
    bottleneck_ranking = bottleneck.rank_bottlenecks(catalog, "model3")
    top = bottleneck_ranking["ranking"][0] if bottleneck_ranking["ranking"] else {}
    report = analytics.anomaly_report(catalog, "model3", top=3)
    return {
        "task": "overview",
        "models": [m["label"] for m in catalog.dataset_summaries() if m["kind"] == "simulation" and m["present"]],
        "inspection": {
            "classes": list(catalog.vision_classes.keys()),
            "counts": catalog.vision_classes,
            "localization_available": False,
        },
        "quality": {
            "usable_columns": sum(1 for d in catalog.dataset_summaries() if d["present"] for _ in range(d["columns"])),
            "missing_cells": sum(i.rows_affected for i in catalog.issues if "missing cells" in i.message),
            "duplicate_rows": sum(i.rows_affected for i in catalog.issues if "duplicated rows" in i.message),
            "anomalous_fraction": report["anomalous_fraction"],
            "issues": [i.message for i in catalog.issues],
        },
        "bottleneck": {
            "label": top.get("label"),
            "utilization": top.get("utilization"),
            "capacity": top.get("capacity"),
            "queue_mean": top.get("queue_mean"),
            "headroom_pct": (top.get("headroom") or 0) * 100.0 if top else None,
            "ranking": [
                {"label": r["label"], "score": r["bottleneck_score"], "utilization": r["utilization"]}
                for r in bottleneck_ranking["ranking"][:4]
            ],
        },
        "calibration": analytics.calibration_report(catalog, "model3"),
        "linkage": catalog.linkage_report(),
        "capabilities": catalog.capabilities(),
        "limitations": [
            "No dataset contains a timestamp, batch identifier or defect label for individual parts.",
            "No dataset contains cost, scrap, rework or downtime values, so no economic figure can be computed.",
            "The image archive and the simulation exports share no key, so defect classes cannot be attached to "
            "stations from data.",
        ],
        "unavailable": list(catalog.capabilities()["reasons"].values()),
    }


def _case_evidence(case_id: str, key: str = "model3") -> Dict[str, Any]:
    case = forensics.build_case(catalog, key, case_id)
    return {
        "task": "case",
        "case_id": case["case_id"],
        "label": case["label"],
        "scope": case["scope"],
        "statistic": case["statistic"],
        "baseline_definition": case["baseline_definition"],
        "first_divergence": case["first_divergence"],
        "co_occurring": case["co_occurring"],
        "outcome": case["outcome"],
        "timeline": case["timeline"],
        "confidence": case["confidence"],
        "confidence_basis": case["confidence_basis"],
        "limitations": case["limitations"],
        "capabilities": catalog.capabilities(),
    }


def _station_evidence(station: str, key: str = "model3") -> Dict[str, Any]:
    rows = bottleneck.station_rows(catalog, key)
    row = next((r for r in rows if r["station"] == station), None)
    if row is None:
        raise HTTPException(status_code=404, detail=f"unknown station '{station}'")
    ranking = bottleneck.rank_bottlenecks(catalog, key)
    rank = next((r for r in ranking["ranking"] if r["station"] == station), None)
    return {
        "task": "station",
        "station": station,
        "label": row["label"],
        "stage": row["stage"],
        "capacity": row["capacity"],
        "capacity_source": row["capacity_source"],
        "utilization": row["utilization"],
        "utilization_source": row["utilization_source"],
        "queue_mean": row["queue_mean"],
        "queue_max": row["queue_max"],
        "headroom": row["headroom"],
        "rank": rank.get("rank") if rank else None,
        "score_components": (rank or {}).get("score_components", {}),
        "evidence": (rank or {}).get("evidence", []),
        "limitations": [
            "Utilisation ranks are computed from a stochastic simulation export, not from a physical line.",
            "No downtime, scrap or rework column exists, so a constraint cannot be attributed to a failure mode.",
        ],
        "unavailable": row.get("unavailable", []),
    }


@router.get("/ai/status")
def ai_status() -> Dict[str, Any]:
    return {**ai_client.status(), "usage": ai_client.usage_summary()}


@router.get("/ai/narrative")
def narrative(
    topic: str = Query("overview", pattern="^(overview|case|station|scenario)$"),
    subject_id: str | None = Query(None, description="case id or station key"),
    key: str = Query("model3"),
    refresh: bool = Query(False, description="bypass the cache and regenerate"),
) -> Dict[str, Any]:
    if topic == "overview":
        evidence = _overview_evidence()
        subject_id = subject_id or "overview"
    elif topic == "case":
        evidence = _case_evidence(subject_id or "group:lowest-output-1pct", key)
    elif topic == "station":
        if not subject_id:
            raise HTTPException(status_code=400, detail="subject_id (station key) is required for the station topic")
        evidence = _station_evidence(subject_id, key)
    else:
        evidence = {
            "task": "scenario",
            "engine": "discrete_event_resimulation",
            "summary": {"note": "no scenario was supplied; open the What-If view to generate one"},
            "validation": {},
            "limitations": ["A scenario narrative requires a scenario run."],
        }
    return ai_client.narrative(topic, subject_id or "unknown", evidence, use_cache=not refresh)


@router.post("/ai/ask")
def ask(payload: AIQuestion) -> Dict[str, Any]:
    """Answer a question strictly from backend-computed evidence."""
    if payload.scope == "case":
        evidence = _case_evidence(payload.subject_id or "group:lowest-output-1pct")
    elif payload.scope == "station":
        if not payload.subject_id:
            raise HTTPException(status_code=400, detail="subject_id (station key) is required")
        evidence = _station_evidence(payload.subject_id)
    else:
        evidence = _overview_evidence()
    evidence["question_scope"] = payload.scope
    return ai_client.narrative("question", payload.subject_id or "overview", evidence, question=payload.question)


@router.get("/ai/logs")
def ai_logs(limit: int = Query(25, ge=1, le=200)) -> Dict[str, Any]:
    """Every AI API attempt, so usage and failures stay visible."""
    return {"logs": ai_client.recent_logs(limit=limit), "usage": ai_client.usage_summary()}
