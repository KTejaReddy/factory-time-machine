"""What-if simulation endpoints."""

from __future__ import annotations

import json
from typing import Any, Dict, List

from fastapi import APIRouter, Body, HTTPException, Query

from ..db import ScenarioRun, insert_row, list_rows
from ..schemas import CostRateCard, ScenarioSpec
from ..services import economics, simulation
from ..services.catalog import catalog

router = APIRouter(prefix="/api/simulation", tags=["simulation"])


@router.get("/options")
def options() -> Dict[str, Any]:
    """Only the scenarios the available data actually supports."""
    return simulation.scenario_options(catalog)


@router.post("/run")
def run(
    spec: ScenarioSpec = Body(...),
    rates: CostRateCard | None = Body(default=None),
    engineer: str = Query("anonymous"),
    save: bool = Query(True, description="store the run so it appears in the scenario history"),
) -> Dict[str, Any]:
    try:
        result = simulation.run_scenario(catalog, spec, rates)
    except KeyError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    if save:
        try:
            row = insert_row(
                ScenarioRun(
                    name=spec.name,
                    engine=result["engine"],
                    scenario=json.dumps(spec.model_dump(), default=str),
                    baseline=json.dumps(result.get("current_snapshot", {}), default=str),
                    result=json.dumps(
                        {"comparisons": result["comparisons"], "summary": result["summary"]}, default=str
                    ),
                    validation=json.dumps(result.get("validation", {}), default=str),
                    engineer=engineer,
                )
            )
            result["saved_run_id"] = row.id
        except Exception as exc:  # pragma: no cover - storage is best effort
            result["saved_run_id"] = None
            result["save_error"] = str(exc)
    return result


@router.get("/history")
def history(limit: int = Query(25, ge=1, le=200)) -> List[Dict[str, Any]]:
    return [row.as_dict() for row in list_rows(ScenarioRun, limit=limit)]


@router.get("/validation")
def validation() -> Dict[str, Any]:
    """Baseline validation of the re-simulation against the exported columns.

    The spec is a bare re-run of the documented route: ``combined`` changes nothing
    (zero capacity delta, unit time factor), so this is the untouched baseline the
    exported columns are compared against.
    """
    try:
        sim = simulation._simulate(catalog, ScenarioSpec(name="baseline validation", kind="combined"))
    except KeyError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    return {
        "engine": "discrete_event_resimulation",
        "validation": simulation.validate(catalog, sim),
        "baseline": simulation.baseline_metrics(catalog),
        "advisory": simulation.ADVISORY,
    }
