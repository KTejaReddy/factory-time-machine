"""Forensic tracing and propagation graph generation."""

from typing import Any, Dict, List
from .catalog import catalog
from .domain import MODELS

def build_propagation_graph(dataset_key: str) -> Dict[str, Any]:
    """Dynamically build a causal graph from available data."""
    if dataset_key not in MODELS:
        return {"status": "unavailable", "reason": "Model definition not found."}
        
    model = MODELS[dataset_key]
    profile = catalog.profiles.get(dataset_key, {})
    manufacturing = profile.get("manufacturing", {})
    
    nodes = []
    edges = []
    
    # Add station nodes
    for st in model.stations:
        nodes.append({"id": st.key, "label": st.label, "type": "station"})
        
    # Infer edges based on route_index
    sorted_stations = sorted(model.stations, key=lambda s: s.route_index)
    for i in range(len(sorted_stations) - 1):
        edges.append({
            "source": sorted_stations[i].key,
            "target": sorted_stations[i+1].key,
            "label": "Process Relationship",
            "type": "observed_sequence"
        })
        
    # Add quality and process variables if available
    for var in manufacturing.get("process_vars", []):
        nodes.append({"id": var, "label": var, "type": "process_variable"})
        # Heuristic: link to nearest station by string matching
        for st in model.stations:
            if st.key.lower() in var.lower():
                edges.append({
                    "source": var,
                    "target": st.key,
                    "label": "Statistical Association",
                    "type": "statistical"
                })
                
    if not nodes:
        return {"status": "unavailable", "reason": "No stations or variables found to build graph."}
        
    return {
        "status": "success",
        "nodes": nodes,
        "edges": edges,
        "basis": "Process order inferred from station definitions and variable names."
    }
