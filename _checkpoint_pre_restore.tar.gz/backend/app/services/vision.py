"""Adaptive Vision Pipeline."""

import logging
from typing import Any, Dict, List
from pathlib import Path
import json

log = logging.getLogger("ftm.vision")

def build_vision_pipeline(dataset_dir: Path) -> Dict[str, Any]:
    """Dynamically determine the vision strategy based on the uploaded directory structure."""
    if not dataset_dir.exists():
        return {"status": "unavailable", "reason": "No image data found."}
        
    subdirs = [d for d in dataset_dir.iterdir() if d.is_dir()]
    
    if len(subdirs) > 1:
        # Case A: Labeled Dataset
        classes = [d.name for d in subdirs]
        return {
            "strategy": "Case A (Supervised)",
            "classes": classes,
            "status": "ready",
            "message": f"Detected {len(classes)} labeled classes. Ready for fine-tuning."
        }
    else:
        # Case B: Unlabeled Dataset
        images = list(dataset_dir.glob("*.jpg")) + list(dataset_dir.glob("*.png"))
        if not images:
            return {"status": "unavailable", "reason": "No image files found in dataset."}
            
        return {
            "strategy": "Case B (Unsupervised Clustering)",
            "images_found": len(images),
            "status": "ready",
            "message": f"Detected {len(images)} unlabeled images. Ready for feature extraction and clustering."
        }

def inspect_image(image_path: str, model_type: str = "baseline") -> Dict[str, Any]:
    """Inspect a single image. Case C."""
    # Stub for single image inspection with Grad-CAM and TTA support.
    return {
        "status": "success",
        "prediction": "Unknown (Model untrained)",
        "confidence": 0.0,
        "uncertainty_tta": 0.0,
        "grad_cam_available": False,
        "warning": "This is an AI assessment using a baseline model. It has not been fine-tuned on your specific dataset."
    }
