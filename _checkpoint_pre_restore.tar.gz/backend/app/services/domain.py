"""Dynamic domain generation from user datasets."""

from typing import Dict, List, Optional
from dataclasses import dataclass, field
import logging

log = logging.getLogger("ftm.domain")

@dataclass(frozen=True)
class StationSpec:
    key: str
    label: str
    stage: str
    route_index: int
    utilization_column: Optional[str] = None
    queue_columns: tuple = ()
    processing_time_seconds: Optional[float] = None
    capacity: Optional[float] = 1.0

@dataclass(frozen=True)
class ModelDef:
    key: str
    label: str
    stages: List[str]
    stations: List[StationSpec]
    factors: Dict[str, Optional[str]] = field(default_factory=dict)
    throughput_columns: Dict[str, str] = field(default_factory=dict)
    wip_columns: tuple = ()
    notes: List[str] = field(default_factory=list)

# The global dynamic store replacing the hardcoded dict
MODELS: Dict[str, ModelDef] = {}

def build_dynamic_domain(dataset_key: str, profile: dict) -> ModelDef:
    """Build a domain model dynamically based on dataset features."""
    manufacturing = profile.get("manufacturing", {})
    cols = profile.get("columns", [])
    
    stations = []
    stages = []
    
    # Infer stations from column names containing 'util', 'queue', 'station', 'machine'
    discovered_station_names = set()
    for col in cols:
        col_lower = col.lower()
        if "util" in col_lower or "queue" in col_lower:
            parts = col.split("_")
            if parts:
                discovered_station_names.add(parts[0])
                
    # Fallback to explicit stations if any
    for st in manufacturing.get("stations", []):
        discovered_station_names.add(st)
        
    for i, st_name in enumerate(sorted(discovered_station_names)):
        stage_name = st_name.capitalize()
        stages.append(stage_name)
        util_cols = [c for c in cols if st_name in c and "util" in c.lower()]
        queue_cols = [c for c in cols if st_name in c and "queue" in c.lower()]
        
        stations.append(StationSpec(
            key=st_name.lower(),
            label=stage_name,
            stage=stage_name,
            route_index=i,
            utilization_column=util_cols[0] if util_cols else None,
            queue_columns=tuple(queue_cols),
            processing_time_seconds=None, # Cannot infer without domain knowledge, simulation falls to Level 2
            capacity=1.0
        ))
        
    throughput_cols = {c: "Throughput" for c in cols if "output" in c.lower() or "throughput" in c.lower()}
    
    model = ModelDef(
        key=dataset_key,
        label=f"Dataset {dataset_key}",
        stages=stages,
        stations=stations,
        throughput_columns=throughput_cols
    )
    MODELS[dataset_key] = model
    return model

def station_sort_key(spec: StationSpec) -> tuple:
    return (spec.route_index, )
