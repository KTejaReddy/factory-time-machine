"""Economic impact.

The rule this module enforces
-----------------------------
**No monetary value is ever produced from the dataset**, because no dataset in
this project contains one. A scan of the Arena files shows the industrial models
*do* carry costing constructs (``V_VACost``, ``V_NVACost``, ``V_TranCost``,
``V_WaitCost``, ``Holding Cost / Hour``, ``Costing_Use``), but none of those
values is exported in any CSV, and no currency, price, scrap count or downtime
figure exists anywhere in the data.

So the API returns ``available: false`` with the precise reason, and the only way
to get a number is for an engineer to supply a rate card. When they do, the
*quantities* still come from the dataset and every line records which side it came
from, so a reader can never mistake a user-supplied rate for measured data.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Sequence

import numpy as np

from ..config import settings
from ..schemas import CostRateCard
from . import domain
from .catalog import Catalog

log = logging.getLogger("ftm.economics")

DISCLAIMER = (
    "Quantities come from the supplied dataset; every rate is entered by the user and is not part of any "
    "dataset. Figures are advisory and are not accounting values."
)

MISSING_VARIABLES = [
    "unit price or margin per product",
    "scrap count and scrap cost",
    "rework count and rework cost",
    "downtime hours",
    "holding cost per unit per hour",
    "currency and cost-accounting basis",
]

#: What the Arena files reference but never export (found by scanning the .doe files).
ARENA_COSTING_NOT_EXPORTED = [
    "Costing_Use",
    "V_VACost",
    "V_NVACost",
    "V_TranCost",
    "V_WaitCost",
    "V_OtherCost",
    "InitVACost",
    "InitNVACost",
    "InitTranCost",
    "Holding Cost / Hour",
    "Cost to Duplicates",
]


def _rates_provided(rate_card: Optional[CostRateCard]) -> bool:
    if rate_card is None:
        return False
    return any(
        getattr(rate_card, field) is not None
        for field in (
            "margin_per_unit",
            "cost_per_unit_scrapped",
            "holding_cost_per_unit_hour",
            "downtime_cost_per_hour",
            "rework_cost_per_unit",
        )
    )


def _line(
    label: str,
    quantity: Optional[float],
    unit: str,
    rate: Optional[float],
    amount: Optional[float],
    quantity_source: str,
    note: str = "",
) -> Dict[str, Any]:
    return {
        "label": label,
        "quantity": quantity,
        "unit": unit,
        "rate": rate,
        "amount": amount,
        "quantity_source": quantity_source,
        "rate_source": "user-supplied" if rate is not None else "not supplied",
        "note": note,
    }


def assess(catalog: Catalog, key: str = "model3", rate_card: Optional[CostRateCard] = None) -> Dict[str, Any]:
    """Economic assessment of the current dataset state."""
    provided = _rates_provided(rate_card)
    available_quantities = _available_quantities(catalog, key)

    if not provided:
        return {
            "available": False,
            "reason": (
                "Economic impact cannot be calculated from the current dataset. No model exports a price, "
                "cost, scrap count, rework count or downtime figure, so there is nothing to multiply by a "
                "quantity. Supply a rate card to compute an advisory figure from the measured quantities."
            ),
            "currency": rate_card.currency if rate_card else None,
            "lines": [],
            "total": None,
            "missing_variables": MISSING_VARIABLES,
            "dataset_supplied_values": available_quantities["labels"],
            "arena_costing_not_exported": ARENA_COSTING_NOT_EXPORTED,
            "disclaimer": DISCLAIMER,
        }

    hours = settings.sim_horizon_seconds / 3600.0
    lines: List[Dict[str, Any]] = []

    wip = available_quantities.get("wip_parts")
    if rate_card and rate_card.holding_cost_per_unit_hour is not None and wip is not None:
        amount = wip * rate_card.holding_cost_per_unit_hour * hours
        lines.append(
            _line(
                "Work-in-process holding cost",
                wip,
                "parts (mean queue/WIP)",
                rate_card.holding_cost_per_unit_hour,
                amount,
                available_quantities["wip_source"],
                f"applied over the {hours:.1f} h horizon",
            )
        )

    spread = available_quantities.get("output_spread")
    if rate_card and rate_card.margin_per_unit is not None and spread is not None:
        lines.append(
            _line(
                "Unrealised output vs the best measured replication",
                spread["quantity"],
                "parts between the population mean and the 99th percentile",
                rate_card.margin_per_unit,
                spread["quantity"] * rate_card.margin_per_unit,
                spread["source"],
                "measures the output spread observed across independent replications, not a proven loss event",
            )
        )

    if rate_card and rate_card.rework_cost_per_unit is not None:
        lines.append(
            _line(
                "Rework",
                None,
                "units",
                rate_card.rework_cost_per_unit,
                None,
                "not available",
                "no export contains a rework count, so this line cannot be evaluated",
            )
        )
    if rate_card and rate_card.cost_per_unit_scrapped is not None:
        lines.append(
            _line(
                "Scrap",
                None,
                "units",
                rate_card.cost_per_unit_scrapped,
                None,
                "not available",
                "Model 3.doe contains scrap logic but no scrap count is exported, so this line cannot be evaluated",
            )
        )
    if rate_card and rate_card.downtime_cost_per_hour is not None:
        lines.append(
            _line(
                "Downtime",
                None,
                "hours",
                rate_card.downtime_cost_per_hour,
                None,
                "not available",
                "no export contains a downtime column, so this line cannot be evaluated",
            )
        )

    total = sum(l["amount"] for l in lines if l["amount"] is not None)
    return {
        "available": bool([l for l in lines if l["amount"] is not None]),
        "reason": (
            "computed from dataset quantities multiplied by user-supplied rates"
            if [l for l in lines if l["amount"] is not None]
            else "the supplied rate card does not match any quantity that exists in the dataset"
        ),
        "currency": rate_card.currency if rate_card else None,
        "lines": lines,
        "total": float(total) if [l for l in lines if l["amount"] is not None] else None,
        "missing_variables": [v for v in MISSING_VARIABLES if not _addressed(v, rate_card)],
        "dataset_supplied_values": available_quantities["labels"],
        "arena_costing_not_exported": ARENA_COSTING_NOT_EXPORTED,
        "disclaimer": DISCLAIMER,
    }


def _addressed(variable: str, rate_card: Optional[CostRateCard]) -> bool:
    if not rate_card:
        return False
    if "holding cost" in variable:
        return rate_card.holding_cost_per_unit_hour is not None
    if "margin" in variable:
        return rate_card.margin_per_unit is not None
    if "rework" in variable:
        return rate_card.rework_cost_per_unit is not None
    if "scrap" in variable:
        return rate_card.cost_per_unit_scrapped is not None
    if "downtime" in variable:
        return rate_card.downtime_cost_per_hour is not None
    return False


def _available_quantities(catalog: Catalog, key: str) -> Dict[str, Any]:
    out: Dict[str, Any] = {"labels": []}
    try:
        if key == "model3":
            parts = catalog._derived.get("model3_parts", {}).get("total_parts")
            sample = catalog.sample_df("model3")
            if parts is not None:
                out["throughput_parts"] = float(parts.mean())
                out["labels"].append("assembled parts per run (sum of exported cell counters)")
                out["output_spread"] = {
                    "quantity": float(np.nanquantile(parts, 0.99) - parts.mean()),
                    "source": "sum of exported c_CellX__SKUY counters across 605,620 replications",
                }
            queue_cols = [
                c
                for station in domain.MODEL3_STATIONS
                for c in station.queue_columns
                if c in sample.columns
            ]
            if queue_cols:
                wip = float(np.mean([float(sample[c].mean()) for c in queue_cols]))
                out["wip_parts"] = wip
                out["wip_source"] = "exported queue columns (the export has no dedicated WIP column)"
                out["labels"].append("queue lengths / WIP (exported queue columns)")
            wait_cols = [c for c in sample.columns if c.startswith("SKU") and c.endswith("_Wait_Time")]
            if wait_cols:
                out["wait_time_seconds"] = float(np.mean([float(sample[c].mean()) for c in wait_cols]))
                out["labels"].append("per-SKU waiting time (exported time-breakdown columns)")
        else:
            spec = domain.MODELS[key]
            df = catalog.model_df(key)
            for column in spec.throughput_columns:
                if column in df.columns:
                    out["labels"].append(f"{column} (exported throughput column)")
                    out["throughput_parts"] = float(catalog.population_stats(key).loc[column, "mean"])
                    break
            wip_cols = [c for c in spec.wip_columns if c in df.columns]
            if wip_cols:
                out["wip_parts"] = float(np.mean([float(catalog.population_stats(key).loc[c, "mean"]) for c in wip_cols]))
                out["wip_source"] = "exported stored-part counters"
                out["labels"].append("stored parts (exported WIP counters)")
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("could not derive economic quantities: %s", exc)
    return out


def economics_for_scenario(catalog: Catalog, payload: Dict[str, Any], rate_card: Optional[CostRateCard]) -> Dict[str, Any]:
    """Valuation of a what-if delta, again gated on user-supplied rates."""
    base = assess(catalog, "model3", rate_card)
    summary = payload.get("summary", {})
    if not _rates_provided(rate_card) or summary.get("completed_parts") is None:
        return {
            **base,
            "reason": base["reason"]
            if not _rates_provided(rate_card)
            else "the scenario did not report completed parts, so no monetary delta was computed",
        }

    hours = settings.sim_horizon_seconds / 3600.0
    lines = list(base["lines"])
    baseline_completed = summary.get("baseline_released_parts")
    simulated_completed = summary.get("completed_parts")
    if (
        rate_card
        and rate_card.margin_per_unit is not None
        and baseline_completed is not None
        and simulated_completed is not None
    ):
        delta = float(simulated_completed) - float(baseline_completed)
        lines.append(
            _line(
                "Scenario output delta",
                delta,
                "parts completed within the horizon",
                rate_card.margin_per_unit,
                delta * rate_card.margin_per_unit,
                "simulated by the discrete-event engine, calibrated to the measured production volume",
                "a positive value means the scenario completes more parts within the same horizon",
            )
        )
    wip = summary.get("wip_parts_end_of_horizon")
    if rate_card and rate_card.holding_cost_per_unit_hour is not None and wip is not None:
        lines.append(
            _line(
                "Scenario end-of-horizon WIP holding cost",
                wip,
                "parts",
                rate_card.holding_cost_per_unit_hour,
                wip * rate_card.holding_cost_per_unit_hour * hours,
                "simulated end-of-horizon work in process",
                f"applied over the {hours:.1f} h horizon",
            )
        )
    totals = [l["amount"] for l in lines if l["amount"] is not None]
    return {
        "available": bool(totals),
        "reason": "scenario delta valued with user-supplied rates",
        "currency": rate_card.currency if rate_card else None,
        "lines": lines,
        "total": float(sum(totals)) if totals else None,
        "missing_variables": [v for v in MISSING_VARIABLES if not _addressed(v, rate_card)],
        "dataset_supplied_values": base["dataset_supplied_values"],
        "arena_costing_not_exported": ARENA_COSTING_NOT_EXPORTED,
        "disclaimer": DISCLAIMER,
    }
