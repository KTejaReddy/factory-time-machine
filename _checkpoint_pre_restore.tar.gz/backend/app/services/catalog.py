"""Dataset catalog for user uploaded data."""

import logging
import threading
import pandas as pd
from pathlib import Path
from typing import Dict, Any, List, Optional

from .profiler import profile_dataframe
from .capabilities import map_capabilities
from ..schemas import ColumnProfile, DatasetIssue

log = logging.getLogger("ftm.catalog")

UPLOAD_DIR = Path("data/user_datasets")

class StatusWrapper:
    def __init__(self):
        self.state = "idle"
        self.progress = 1.0
        
    def snapshot(self) -> Dict[str, Any]:
        return {"state": self.state, "progress": self.progress}

class Catalog:
    def __init__(self):
        self._lock = threading.Lock()
        self.frames: Dict[str, pd.DataFrame] = {}
        self.profiles: Dict[str, Dict[str, Any]] = {}
        self.capabilities: Dict[str, Dict[str, Any]] = {}
        self.status = StatusWrapper()
        self.issues = []
        self.vision_classes = []
        self.vision_index = []
        
    def start_background_build(self, force: bool = False):
        # In a real app this would be a background task
        self.build()
        
    def build(self, force: bool = False):
        with self._lock:
            self.frames.clear()
            self.profiles.clear()
            self.capabilities.clear()
            
            if not UPLOAD_DIR.exists():
                return
                
            for path in UPLOAD_DIR.glob("*.csv"):
                try:
                    df = pd.read_csv(path)
                    name = path.stem
                    self.frames[name] = df
                    prof = profile_dataframe(df)
                    self.profiles[name] = prof
                    self.capabilities[name] = map_capabilities(prof)
                    
                    from .domain import build_dynamic_domain
                    build_dynamic_domain(name, prof)
                except Exception as e:
                    log.error(f"Failed to load {path}: {e}")

    def dataset_summaries(self) -> List[Dict[str, Any]]:
        return [
            {
                "key": name,
                "label": f"User Dataset: {name}",
                "kind": "simulation",
                "present": True,
                "rows": int(prof["stats"]["rows"]),
                "columns": len(prof["columns"]),
                "extras": {"capabilities": self.capabilities.get(name, {})}
            }
            for name, prof in self.profiles.items()
        ]

    def model_df(self, key: str) -> pd.DataFrame:
        if key not in self.frames:
            raise KeyError(f"dataset '{key}' not found")
        return self.frames[key]

    def sample_df(self, key: str) -> pd.DataFrame:
        return self.model_df(key).head(100)

    def population_stats(self, key: str) -> pd.DataFrame:
        df = self.model_df(key)
        return df.describe().T

    def population_quantiles(self, key: str, columns: List[str]) -> pd.DataFrame:
        return self.model_df(key)[columns].quantile([0.05, 0.25, 0.5, 0.75, 0.95]).T

    def mat_summary_lazy(self) -> Dict[str, Any]:
        return {"present": False}

    def image_bytes(self, name: str) -> bytes:
        return b""

    def thumbnail(self, name: str, size: int = 160) -> bytes:
        return b""

    def find_specimen(self, specimen: str) -> Optional[Dict[str, Any]]:
        return None

    def linkage_report(self) -> Dict[str, Any]:
        return {"joinable": False, "shared_keys": [], "vision_domain": {}, "simulation_domain": {}, "statement": "Files cannot be reliably linked."}

    def get_capabilities(self) -> Dict[str, Any]:
        return self.capabilities.get("current", {})

    def provenance(self) -> Dict[str, Any]:
        return {"sources": [], "horizon": {"seconds": 3600, "source": "default"}, "documents": [], "derived_columns": []}

    def profile_map(self, key: str) -> Dict[str, Any]:
        return {}

catalog = Catalog()
