from typing import Any, Dict

def map_capabilities(profile: Dict[str, Any]) -> Dict[str, Any]:
    """Determine what analytical features are supported by this dataset."""
    m = profile.get("manufacturing", {})
    has_cost = len(m.get("cost_fields", [])) > 0
    has_stations = len(m.get("stations", [])) > 0
    has_process = len(m.get("process_vars", [])) > 0
    has_batches = m.get("batch_ids", False)

    return {
        "Defect Classification": True, # Provided by vision module or clustering
        "Process Anomaly Detection": has_process,
        "Batch Comparison": has_batches,
        "Bottleneck Analysis": has_stations and has_process,
        "Cost Analysis": has_cost,
        "Defect Localization": False, # Requires annotations
        "Simulation": has_stations and has_process
    }
