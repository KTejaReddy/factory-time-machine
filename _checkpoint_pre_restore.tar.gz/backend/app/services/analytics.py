"""Analytics engine for calculating process anomalies and correlations from a dynamic dataset."""

from typing import Any, Dict, List
import pandas as pd
import numpy as np

from .catalog import catalog
from .domain import MODELS

def calculate_mahalanobis(df: pd.DataFrame, process_cols: List[str]) -> pd.DataFrame:
    """Calculate Mahalanobis distance for anomaly detection."""
    df_clean = df[process_cols].dropna()
    if len(df_clean) < 10 or len(process_cols) < 2:
        return df_clean
    
    # Log transform
    df_log = np.log1p(df_clean - df_clean.min() + 1)
    # Standardize
    df_std = (df_log - df_log.mean()) / df_log.std()
    
    # Covariance
    cov = np.cov(df_std.values.T)
    try:
        inv_cov = np.linalg.inv(cov)
    except np.linalg.LinAlgError:
        inv_cov = np.linalg.pinv(cov)
        
    diff = df_std - df_std.mean()
    m_dist = np.sqrt(np.sum(np.dot(diff, inv_cov) * diff, axis=1))
    
    return m_dist

def analyze_anomalies(dataset_key: str) -> Dict[str, Any]:
    """Run anomaly detection using whatever process variables are available."""
    capabilities = catalog.capabilities.get(dataset_key, {})
    if not capabilities.get("Process Anomaly Detection", False):
        return {
            "status": "unavailable",
            "reason": "Not enough valid numeric process variables found in dataset."
        }
        
    df = catalog.model_df(dataset_key)
    profile = catalog.profiles.get(dataset_key, {})
    process_vars = profile.get("manufacturing", {}).get("process_vars", [])
    
    if len(process_vars) < 2:
        return {
            "status": "unavailable",
            "reason": "Multivariate anomaly detection requires at least 2 process variables."
        }
        
    distances = calculate_mahalanobis(df, process_vars)
    if distances is None or len(distances) == 0:
        return {"status": "unavailable", "reason": "Failed to calculate distances (likely due to NaNs)."}
        
    threshold = np.percentile(distances, 99.5)
    anomalies = distances[distances > threshold]
    
    return {
        "status": "success",
        "variables_used": process_vars,
        "total_analyzed": len(distances),
        "anomalies_detected": len(anomalies),
        "threshold": float(threshold)
    }

def get_correlations(dataset_key: str) -> Dict[str, Any]:
    """Calculate statistical correlations dynamically."""
    df = catalog.model_df(dataset_key)
    profile = catalog.profiles.get(dataset_key, {})
    numerical = profile.get("types", {}).get("numerical", [])
    
    if len(numerical) < 2:
         return {"status": "unavailable", "reason": "Insufficient numerical columns for correlation."}
         
    corr = df[numerical].corr().to_dict()
    return {"status": "success", "correlations": corr}
