from typing import Any, Dict, List
import pandas as pd
import numpy as np

def profile_dataframe(df: pd.DataFrame) -> Dict[str, Any]:
    """Analyze a dataframe to infer its structure and capabilities."""
    columns = list(df.columns)
    
    # Try to identify column types
    categorical = []
    numerical = []
    identifiers = []
    timestamps = []
    
    for col in columns:
        if "id" in col.lower() or "batch" in col.lower() or "run" in col.lower():
            identifiers.append(col)
        elif "time" in col.lower() or "date" in col.lower():
            timestamps.append(col)
        elif pd.api.types.is_numeric_dtype(df[col]):
            numerical.append(col)
        else:
            categorical.append(col)
            
    # Try to identify specific manufacturing variables
    stations = [c for c in columns if "station" in c.lower() or "machine" in c.lower()]
    cost_fields = [c for c in columns if "cost" in c.lower() or "price" in c.lower() or "revenue" in c.lower()]
    process_vars = [c for c in columns if "util" in c.lower() or "queue" in c.lower() or "temp" in c.lower()]
    
    return {
        "columns": columns,
        "types": {
            "categorical": categorical,
            "numerical": numerical,
            "identifiers": identifiers,
            "timestamps": timestamps
        },
        "manufacturing": {
            "stations": stations,
            "cost_fields": cost_fields,
            "process_vars": process_vars,
            "batch_ids": len(identifiers) > 0
        },
        "stats": {
            "rows": len(df),
            "missing": int(df.isna().sum().sum()),
        }
    }
