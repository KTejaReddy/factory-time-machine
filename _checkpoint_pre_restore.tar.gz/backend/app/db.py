"""SQLite persistence (PostgreSQL-compatible SQLAlchemy models).

Stores human-in-the-loop feedback, engineer-declared dataset linkage
assumptions, what-if scenario runs, AI narratives and AI call logs.

The schema deliberately stays portable: no SQLite-specific types, JSON stored as
TEXT, timestamps stored as UTC datetimes.
"""

from __future__ import annotations

import datetime as dt
import json
from contextlib import contextmanager
from typing import Any, Dict, Iterator, List, Optional

from sqlalchemy import (
    Boolean,
    DateTime,
    Float,
    Integer,
    String,
    Text,
    create_engine,
    select,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

from .config import ensure_dirs, settings

engine = create_engine(settings.database_url, future=True)
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False, future=True)


def utcnow() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


class Base(DeclarativeBase):
    pass


def _json_load(raw: Optional[str]) -> Any:
    if not raw:
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return None


# ---------------------------------------------------------------------------
# Tables
# ---------------------------------------------------------------------------
class FeedbackItem(Base):
    """Engineer verdict on a single AI finding."""

    __tablename__ = "feedback_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    finding_id: Mapped[str] = mapped_column(String(160), index=True)
    finding_kind: Mapped[str] = mapped_column(String(60))
    finding_title: Mapped[str] = mapped_column(String(400))
    #: The exact evidence payload the engineer was shown, stored verbatim.
    payload: Mapped[str] = mapped_column(Text, default="{}")
    decision: Mapped[str] = mapped_column(String(20))  # confirmed | rejected | needs_review
    note: Mapped[str] = mapped_column(Text, default="")
    engineer: Mapped[str] = mapped_column(String(120), default="anonymous")
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "finding_id": self.finding_id,
            "finding_kind": self.finding_kind,
            "finding_title": self.finding_title,
            "payload": _json_load(self.payload),
            "decision": self.decision,
            "note": self.note,
            "engineer": self.engineer,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class LinkageAssumption(Base):
    """Engineer-declared bridge between the vision domain and the process domain.

    The datasets share no key (see DATASET_SCHEMA.md section 4), so any
    defect-class -> station edge is an explicit, logged assumption.
    """

    __tablename__ = "linkage_assumptions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    defect_class: Mapped[str] = mapped_column(String(80), index=True)
    station: Mapped[str] = mapped_column(String(80), index=True)
    rationale: Mapped[str] = mapped_column(Text, default="")
    author: Mapped[str] = mapped_column(String(120), default="anonymous")
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "defect_class": self.defect_class,
            "station": self.station,
            "rationale": self.rationale,
            "author": self.author,
            "active": self.active,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class ScenarioRun(Base):
    """A stored what-if run: scenario definition, baseline and simulated result."""

    __tablename__ = "scenario_runs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    engine: Mapped[str] = mapped_column(String(40), default="des")
    scenario: Mapped[str] = mapped_column(Text, default="{}")
    baseline: Mapped[str] = mapped_column(Text, default="{}")
    result: Mapped[str] = mapped_column(Text, default="{}")
    validation: Mapped[str] = mapped_column(Text, default="{}")
    engineer: Mapped[str] = mapped_column(String(120), default="anonymous")
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "engine": self.engine,
            "scenario": _json_load(self.scenario),
            "baseline": _json_load(self.baseline),
            "result": _json_load(self.result),
            "validation": _json_load(self.validation),
            "engineer": self.engineer,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class Narrative(Base):
    """Cached AI narrative together with the structured evidence it was given."""

    __tablename__ = "narratives"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    topic: Mapped[str] = mapped_column(String(60), index=True)
    subject_id: Mapped[str] = mapped_column(String(200), index=True)
    provider: Mapped[str] = mapped_column(String(40))
    model: Mapped[str] = mapped_column(String(120))
    content: Mapped[str] = mapped_column(Text, default="{}")
    evidence: Mapped[str] = mapped_column(Text, default="{}")
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "topic": self.topic,
            "subject_id": self.subject_id,
            "provider": self.provider,
            "model": self.model,
            "content": _json_load(self.content),
            "evidence": _json_load(self.evidence),
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class AICallLog(Base):
    """Every AI API attempt is logged so cost/usage stays observable."""

    __tablename__ = "ai_call_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    topic: Mapped[str] = mapped_column(String(60))
    provider: Mapped[str] = mapped_column(String(40))
    model: Mapped[str] = mapped_column(String(120))
    ok: Mapped[bool] = mapped_column(Boolean, default=False)
    latency_ms: Mapped[float] = mapped_column(Float, default=0.0)
    prompt_chars: Mapped[int] = mapped_column(Integer, default=0)
    error: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "topic": self.topic,
            "provider": self.provider,
            "model": self.model,
            "ok": self.ok,
            "latency_ms": round(self.latency_ms, 1),
            "prompt_chars": self.prompt_chars,
            "error": self.error,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def init_db() -> None:
    ensure_dirs()
    Base.metadata.create_all(engine)


@contextmanager
def session() -> Iterator[Any]:
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def list_rows(model_: type, limit: int = 200, order_desc: bool = True) -> List[Any]:
    with session() as db:
        stmt = select(model_)
        if hasattr(model_, "created_at") and order_desc:
            stmt = stmt.order_by(model_.created_at.desc())
        stmt = stmt.limit(limit)
        return list(db.execute(stmt).scalars())


def insert_row(row: Any) -> Any:
    with session() as db:
        db.add(row)
        db.flush()
        db.refresh(row)
        return row
